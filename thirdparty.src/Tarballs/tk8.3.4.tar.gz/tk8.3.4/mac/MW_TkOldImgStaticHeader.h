#define USE_OLD_IMAGE

#include "MW_TkStaticHeader.pch"
