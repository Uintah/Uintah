/*
 * jversion.h
 *
 * Copyright (C) 1991-1994, Thomas G. Lane.
 * This file is part of the Independent JPEG Group's software.
 * For conditions of distribution and use, see the accompanying README file.
 *
 * This file contains software version identification.
 */


#define JVERSION	"5  24-Sep-94"

#define JCOPYRIGHT	"Copyright (C) 1994, Thomas G. Lane"
