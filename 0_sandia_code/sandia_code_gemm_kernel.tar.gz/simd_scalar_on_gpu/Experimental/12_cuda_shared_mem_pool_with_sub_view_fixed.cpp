//~/installs/Trilinos/install/opt_simd/bin/nvcc_wrapper -std=c++11 -I/ascldap/users/drsahas/installs/Trilinos/install/opt_simd/include/ -L/home/drsahas/installs/Trilinos/install/opt_simd/lib -lkokkoscore cuda_example.cpp
#include <sys/time.h>
#include <math.h>
#include <Kokkos_Core.hpp>
#include <KokkosKernels_Uniform_Initialized_MemoryPool.hpp>
#include <cstdio>
#define WARP_SIZE 32
#define NUM_OF_CHUNKS 6
#define VECTOR_LENGTH 2

int N , L0 , L1;


//if class names or struct names or its field name are changed, then these macros should also be updated
//-------------------------------------- binary operator generalization --------------------------------------------------------

//---------------------------------------- operation by assignment e.g. +=, *= etc. --------------------------------------------
//a is Vector. op is operator
#define bin_op_by_assignment_simd(a, op)	\
  for(int i=0; i<vector_length; i++)	\
    m_thread_val.data[i] = m_thread_val.data[i] op a.m_thread_val.data[i];	\
  return *this;	

//a is temp_data<vector_length>. op is operator
#define bin_op_by_assignment_temp(a, op)	\
  for(int i=0; i<vector_length; i++)	\
    m_thread_val.data[i] = m_thread_val.data[i] op a.data[i];	\
  a.release_temp_data();	\
  return *this;


//---------------------------------------- plain binary operation e.g. +, * etc. --------------------------------------------
//a is Vector. op is operator
#define bin_op_simd(a, op)	\
  int threadNumInBlock = blockDim.x * blockDim.y * threadIdx.z + blockDim.x * threadIdx.y + threadIdx.x;	\
  temp_data<value_type, vector_length> temp(NUM_OF_CHUNKS * threadNumInBlock);	\
  for(int i=0; i<vector_length; i++)	\
    temp.data[i] = m_thread_val.data[i] op a.m_thread_val.data[i];	\
  return temp;


//a is temp_data<vector_length>. op is operator
#define bin_op_temp(a, op)	\
  int threadNumInBlock = blockDim.x * blockDim.y * threadIdx.z + blockDim.x * threadIdx.y + threadIdx.x;	\
  temp_data<value_type, vector_length> temp(NUM_OF_CHUNKS * threadNumInBlock);\
  for(int i=0; i<vector_length; i++)	\
    temp.data[i] = m_thread_val.data[i] op a.data[i];		\
  a.release_temp_data();	\
  return temp;	

//a is temp_data<vector_length>. op is operator
#define bin_op_temp_temp(a, op)	\
    for(int i=0; i<vector_length; i++)	\
	data[i] = data[i] op a.data[i];	\
    a.release_temp_data();	\
    return *this;	



//typedef Kokkos::Cuda::scratch_memory_space cudaspace;
//typedef Kokkos::Cuda::memory_space cudaspace;
//typedef KokkosKernels::Impl::UniformMemoryPool<cudaspace, double> mem_pool_type;
typedef typename Kokkos::TeamPolicy<>::member_type team_member ;

//__device__ mem_pool_type *dev_mem_pool=NULL;
//__device__ team_member *g_thread;
//__device__ double ** scratch_pad;

template <typename value_type, int vector_length=1> 
struct pool
{
  int used{0};
  value_type data[vector_length];
};



typedef Kokkos::Cuda::scratch_memory_space shared_space;
//typedef Kokkos::View<double*,shared_space,Kokkos::MemoryUnmanaged> shared_1d_double;

//__device__ __shared__ void * g_pool;

template <typename value_type, int vector_length=1> class Vector;



template <typename value_type, int vector_length=1>
struct SIMD	//need to use different structs for data field in Vector class and for temp data. temp data comes from pool dynamically, while data element of Vector should have fixed length to cast
{
	value_type data[vector_length];
};

__device__ char *g_pool;


template <typename value_type, int vector_length=1>
struct temp_data
{
	value_type *data;
	pool <value_type, vector_length> * cur_pool;

	__host__ __device__  temp_data(int index)
	{
		
		if(g_pool==NULL)
			printf("g_pool null\n");

		pool<value_type, vector_length> *local_pool = (pool<value_type, vector_length> *)g_pool;

		//printf("allocating\n");

		int i;
		for(i=0; i<NUM_OF_CHUNKS; i++)
		{
			//printf("checking chunk %d\n", i);

			if(local_pool[index+i].used == 0)
			{
				//printf("found chunk %d\n", i);
				local_pool[index+i].used = 1;
				cur_pool = &local_pool[index+i];				
				data = (value_type *)&local_pool[index+i].data;

				//printf("allocated %d %p\n", i, &local_pool[index+i]);
				break;
			}
		}
		if(i==NUM_OF_CHUNKS)
			printf("pool out of memory \n");
	}

	__host__ __device__  ~temp_data() {release_temp_data();	}

	__host__ __device__ inline void  release_temp_data()
	{
		//printf("releasing %p\n", &((int *)data)[-2] );
		cur_pool->used=0;
		//((int *)data)[-2] = 0;
	}

	//-------------------------------------- operator + --------------------------------------------------------

	__host__ __device__ inline temp_data operator+(Vector<value_type, vector_length>& n) { return (n + *this); }	//(a+b) + c

	__host__ __device__ inline temp_data operator+(temp_data a) { bin_op_temp_temp(a, +); }		//case such as  (a+b) + (c+d)
	
	//-------------------------------------- operator - --------------------------------------------------------

	__host__ __device__ inline temp_data operator-(Vector<value_type, vector_length>& n) { return (n - *this); }	//(a-b) - c

	__host__ __device__ inline temp_data operator-(temp_data a) { bin_op_temp_temp(a, -); }		//case such as  (a-b) - (c-d)

	//-------------------------------------- operator * --------------------------------------------------------

	__host__ __device__ inline temp_data operator*(Vector<value_type, vector_length>& n) { return (n * *this); }	//(a*b) * c

	__host__ __device__ inline temp_data operator*(temp_data a) { bin_op_temp_temp(a, *); }		//case such as  (a*b) * (c*d)

	//-------------------------------------- operator / --------------------------------------------------------

	__host__ __device__ inline temp_data operator/(Vector<value_type, vector_length>& n) { return (n / *this); }	//(a/b) / c

	__host__ __device__ inline temp_data operator/(temp_data a) { bin_op_temp_temp(a, /); }		//case such as  (a/b) / (c/d)

	
};

template <typename value_type, int vector_length>
class Vector	//class to be instantiated inside parallel region. 
{
public:
	//-------------------------------------- operator = --------------------------------------------------------

	__host__ __device__ inline Vector operator= (const Vector& a)	//a=b
	{
	  for(int i=0; i<vector_length; i++)
	    m_thread_val.data[i] = a.m_thread_val.data[i];
	  return *this;
	}

	__host__ __device__ inline Vector operator= (temp_data<value_type, vector_length> a)	//a=b+c
	{
	  for(int i=0; i<vector_length; i++)
	    m_thread_val.data[i] = a.data[i];
	  a.release_temp_data();
	  return *this;
	}

//-------------------------------------- operator += and + --------------------------------------------------------
	
	__host__ __device__ inline Vector operator+= (const Vector& a)	{  bin_op_by_assignment_simd(a, +); }  		//a+=b
	
	__host__ __device__ inline Vector operator+= (temp_data<value_type, vector_length> a) {  bin_op_by_assignment_temp(a, +); }		//a+=b+c

	__host__ __device__ inline temp_data<value_type, vector_length> operator+ (const Vector& a)	{ bin_op_simd(a, +); }		//a+b

	__host__ __device__ inline temp_data<value_type, vector_length> operator+ (temp_data<value_type, vector_length> a) { bin_op_temp(a, +); }	//a+b+c

//-------------------------------------- operator -= and - --------------------------------------------------------
	
	__host__ __device__ inline Vector operator-= (const Vector& a)	{  bin_op_by_assignment_simd(a, -); }  		//a-=b
	
	__host__ __device__ inline Vector operator-= (temp_data<value_type, vector_length> a) {  bin_op_by_assignment_temp(a, -); }		//a-=b-c

	__host__ __device__ inline temp_data<value_type, vector_length> operator- (const Vector& a)	{ bin_op_simd(a, -); }		//a-b

	__host__ __device__ inline temp_data<value_type, vector_length> operator- (temp_data<value_type, vector_length> a) { bin_op_temp(a, -); }	//a-b-c

//-------------------------------------- operator *= and * --------------------------------------------------------
	
	__host__ __device__ inline Vector operator*= (const Vector& a)	{  bin_op_by_assignment_simd(a, *); }  		//a*=b
	
	__host__ __device__ inline Vector operator*= (temp_data<value_type, vector_length> a) {  bin_op_by_assignment_temp(a, *); }		//a*=b*c

	__host__ __device__ inline temp_data<value_type, vector_length> operator* (const Vector& a)	{ bin_op_simd(a, *); }		//a*b

	__host__ __device__ inline temp_data<value_type, vector_length> operator* (temp_data<value_type, vector_length> a) { bin_op_temp(a, *); }	//a*b*c

//-------------------------------------- operator /= and / --------------------------------------------------------
	
	__host__ __device__ inline Vector operator/= (const Vector& a)	{  bin_op_by_assignment_simd(a, /); }  		//a/=b
	
	__host__ __device__ inline Vector operator/= (temp_data<value_type, vector_length> a) {  bin_op_by_assignment_temp(a, /); }		//a/=b/c

	__host__ __device__ inline temp_data<value_type, vector_length> operator/ (const Vector& a)	{ bin_op_simd(a, /); }		//a/b

	__host__ __device__ inline temp_data<value_type, vector_length> operator/ (temp_data<value_type, vector_length> a) { bin_op_temp(a, /); }	//a/b/c


private: 

	SIMD <value_type, vector_length> m_thread_val; 	//There will be WARP_SIZE instances of this class. Each instance stores a single value corresponding to it's vector lane i.e. threadIdx.x. 
};


  


template<typename value_type, int vector_length=1 >
struct SomeCorrelation 
{
  Kokkos::View< Vector<value_type, vector_length>*, Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > A, B;

  //mem_pool_type mem_pool;
  int loop_count, N, L0, L1;

  SomeCorrelation(//mem_pool_type mem_pool,
		  Kokkos::View<value_type*,Kokkos::LayoutRight> a,
                  Kokkos::View<value_type*,Kokkos::LayoutRight> b, int L0 , int L1, int N
		 ):N(N),  L0(L0), L1(L1) //,mem_pool(mem_pool)
		{
			Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > A1(reinterpret_cast<Vector<value_type, vector_length>*>(a.data()));
			Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > B1(reinterpret_cast<Vector<value_type, vector_length>*>(b.data()));
			A = A1;
			B = B1;
			N = N/vector_length;	//reinterpret_cast groups doubles into SIMD i.e. array of double[vector_length]. Hence divide N by vector_length
			loop_count = N/L0/L1/WARP_SIZE;	//loop count N/L0 -> total N iterations divided among L0 teams. Again divid by WARP_SIZE. Kokkos will further divide this among L1 threads.
			if(loop_count==0 && N>0)	//if loop_count becomes 0 (when N < L0*WARP_SIZE i.e. all iterations can be accomodated by vectors of single thread) set lopp_count = 1
				loop_count=1;	

		}


  KOKKOS_INLINE_FUNCTION
  void operator() ( const team_member & thread) const 
  {
	//printf("%d %d %d %d %d %d\n", blockIdx.x, blockIdx.y, blockIdx.z, threadIdx.x, threadIdx.y, threadIdx.z);
	char *all_shared_memory = (char *) (thread.team_shmem().get_shmem(L1*WARP_SIZE*NUM_OF_CHUNKS*sizeof(pool<value_type, vector_length>)));
	//printf("got shared memory\n");
	
	if(g_pool==NULL)
		g_pool = all_shared_memory;
	
	int i = thread.league_rank();
	Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, L1), [&] (const int& j) 	
	{
		 Kokkos::parallel_for(Kokkos::ThreadVectorRange(thread, WARP_SIZE ),  [&](const int &k) {
			Kokkos::LayoutStride stride(loop_count, WARP_SIZE);
			Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutStride, Kokkos::MemoryTraits<Kokkos::Unmanaged> > AA(&A[i*loop_count*WARP_SIZE*L1 + j*loop_count*WARP_SIZE + k], stride);
			Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutStride, Kokkos::MemoryTraits<Kokkos::Unmanaged> > BB(&B[i*loop_count*WARP_SIZE*L1 + j*loop_count*WARP_SIZE + k], stride);

			//int index = k;
			for(int index=0; index<loop_count; index++)
			{
				//printf("%d\n", i*loop_count*WARP_SIZE*L1 + j*loop_count*WARP_SIZE + k + index*WARP_SIZE);
			for(int ii=0; ii<1000; ii++)
			{
				AA(index) /= (AA(index) + ((BB(index) + AA(index)) + BB(index))) + (BB(index) + BB(index));
				AA(index) += (AA(index) + ((BB(index) - AA(index)) + BB(index))) + (BB(index) + BB(index)) + (AA(index) / ((BB(index) + AA(index)) + BB(index))) - (BB(index) + BB(index)) + AA(index);
				AA(index) *= (BB(index) + BB(index)) + (BB(index) + BB(index));
				AA(index) -= (BB(index)/BB(index));

				//AA(index) = AA(index) + BB(index);
			}
			}
		});

	});

  }
};

int main(int narg, char* args[]) {
  N = atoi(args[1]);
  L0 = atoi(args[2]);
  L1 = atoi(args[3]);


  Kokkos::initialize(narg,args);

  Kokkos::View<double*,Kokkos::LayoutRight> a("Data",N), b("Data",N);

  

  for(int i = 0; i<N ; i++) 
  {
	a[i] = (double)(i%10) / M_PI;
	b[i] = (double)((i%100) + 1)   / M_PI;
  }

  const Kokkos::TeamPolicy<> policy( L0 , L1, WARP_SIZE);

  //int num_chunks = L0 * L1 * WARP_SIZE * NUM_OF_CHUNKS;

  //mem_pool_type mem_pool(num_chunks, VECTOR_LENGTH, 0,  KokkosKernels::Impl::ManyThread2OneChunk);

  struct timeval  tv1, tv2;
  gettimeofday(&tv1, NULL);

  Kokkos::parallel_for( policy.set_scratch_size(0, Kokkos::PerTeam( L1 * WARP_SIZE * NUM_OF_CHUNKS * sizeof(pool<double, VECTOR_LENGTH>))) , SomeCorrelation<double, VECTOR_LENGTH>(a,b, L0 ,L1, N) );

  Kokkos::fence();

  gettimeofday(&tv2, NULL);
  double exec_time = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);

  //for(int i = 0; i<N ; i++)
//	printf("%0.2f ", a[i]);
	printf("\n\na[N-1],N, L0, L1, vector_length, exec_time:\t9_POOL_and_SUB_VIEW\t%0.2f\t%d\t%d\t%d\t%d\t%f\n",a[N-1],N, L0, L1, VECTOR_LENGTH, exec_time);

  printf("\n");
  Kokkos::finalize();
}

