//~/installs/Trilinos/install/opt_simd/bin/nvcc_wrapper -std=c++11 -I/ascldap/users/drsahas/installs/value_typerilinos/install/opt_simd/include/ -L/home/drsahas/installs/value_typerilinos/install/opt_simd/lib -lkokkoscore cuda_example.cpp
#include <sys/time.h>
#include <Kokkos_Core.hpp>
#include <cstdio>
#define WARP_SIZE 32

int N , L0 , L1;


typedef typename Kokkos::TeamPolicy<>::member_type team_member ;

template <typename value_type>
class Vector	//class to be instantiated inside parallel region. 
{
public:
	//-------------------------------------- operator = --------------------------------------------------------

	__host__ __device__ inline Vector operator= (Vector& a)	{
	  m_thread_val = a.m_thread_val;
	  return *this;
	}

	__host__ __device__ inline Vector operator= (value_type a) {
	  m_thread_val = a;
	  return *this;
	}

	//-------------------------------------- operator += and + --------------------------------------------------------

	__host__ __device__ inline Vector operator+= (Vector& a) {
	  m_thread_val += a.m_thread_val;
	  return *this;
	}

	__host__ __device__ inline Vector operator+= (value_type a)	{
	  m_thread_val += a;
	  return *this;
	}

	__host__ __device__ inline value_type operator+ (Vector& a)	{ return (m_thread_val + a.m_thread_val); }

	__host__ __device__ inline value_type operator+ (value_type a)	{ return (m_thread_val + a); }


	//-------------------------------------- operator *= and * --------------------------------------------------------

	__host__ __device__ inline Vector operator*= (Vector& a) {
	  m_thread_val *= a.m_thread_val;
	  return *this;
	}

	__host__ __device__ inline Vector operator*= (value_type a)	{
	  m_thread_val *= a;
	  return *this;
	}

	__host__ __device__ inline value_type operator* (Vector& a)	{ return (m_thread_val * a.m_thread_val); }

	__host__ __device__ inline value_type operator* (value_type a)	{ return (m_thread_val * a); }


	//-------------------------------------- operator -= and - --------------------------------------------------------

	__host__ __device__ inline Vector operator-= (Vector& a) {
	  m_thread_val -= a.m_thread_val;
	  return *this;
	}

	__host__ __device__ inline Vector operator-= (value_type a)	{
	  m_thread_val -= a;
	  return *this;
	}

	__host__ __device__ inline value_type operator- (Vector& a)	{ return (m_thread_val - a.m_thread_val); }

	__host__ __device__ inline value_type operator- (value_type a)	{ return (m_thread_val - a); }


	//-------------------------------------- operator /= and / --------------------------------------------------------

	__host__ __device__ inline Vector operator/= (Vector& a) {
	  m_thread_val /= a.m_thread_val;
	  return *this;
	}

	__host__ __device__ inline Vector operator/= (value_type a)	{
	  m_thread_val /= a;
	  return *this;
	}

	__host__ __device__ inline value_type operator/ (Vector& a)	{ return (m_thread_val / a.m_thread_val); }

	__host__ __device__ inline value_type operator/ (value_type a)	{ return (m_thread_val / a); }

 	
private: 
	value_type m_thread_val; 	//value_typehere will be WARP_SIZE instances of this class. Each instance stores a single value corresponding to it's vector lane i.e. threadIdx.x. 
};

template <typename value_type> __host__ __device__ inline value_type operator+(value_type a, Vector<value_type>& n) { return (n + a); }	//if first operand is double and second is Vector

template <typename value_type> __host__ __device__ inline value_type operator-(value_type a, Vector<value_type>& n) { return (n - a); }	//if first operand is double and second is Vector

template <typename value_type> __host__ __device__ inline value_type operator*(value_type a, Vector<value_type>& n) { return (n * a); }	//if first operand is double and second is Vector

template <typename value_type> __host__ __device__ inline value_type operator/(value_type a, Vector<value_type>& n) { return (n / a); }	//if first operand is double and second is Vector


template <typename value_type>
struct SomeCorrelation
{
  Kokkos::View<Vector<value_type>*,Kokkos::LayoutRight> A, B;
  int loop_count, N;
  SomeCorrelation(Kokkos::View<value_type*,Kokkos::LayoutRight> a,
                  Kokkos::View<value_type*,Kokkos::LayoutRight> b, int L0 , int N
		 ):N(N)
		{
			Kokkos::View< Vector<value_type>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > A1(reinterpret_cast<Vector<value_type>*>(a.data()));
			Kokkos::View< Vector<value_type>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > B1(reinterpret_cast<Vector<value_type>*>(b.data()));
			A = A1;
			B = B1;
			
			loop_count = N/L0/WARP_SIZE;	//loop count N/L0 -> total N iterations divided among L0 teams. Again divid by WARP_SIZE. Kokkos will further divide this among L1 threads.
			if(loop_count==0 && N>0)	//if loop_count becomes 0 (when N < L0*WARP_SIZE i.e. all iterations can be accomodated by vectors of single thread) set lopp_count = 1
				loop_count=1;	
		}

  KOKKOS_INLINE_FUNCTION
  void operator() ( const team_member & thread) const 
  {
	int i = thread.league_rank();
	Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, loop_count), [&] (const int& j) 	
	{
		int index = i*loop_count*WARP_SIZE + j*WARP_SIZE + threadIdx.x;
		printf("\n %d\t%d\t%d", threadIdx.x, index, N);
		if(index < N)
		{
			for(int ii=0; ii<1000; ii++)
			{
				A(index) /= (A(index) + ((B(index) + A(index)) + B(index))) + (B(index) + B(index));
				A(index) += (A(index) + ((B(index) - A(index)) + B(index))) + (B(index) + B(index)) + (A(index) / ((B(index) + A(index)) + B(index))) - (B(index) + B(index)) + A(index);
			
				A(index) *= (B(index) + B(index)) + (B(index) + B(index));
				A(index) -= (B(index)/B(index));
				//A(index) = A(index) + B(index);//  + A(index);
			}
		}
	});
  }
};

int main(int narg, char* args[]) {
  N = atoi(args[1]);
  L0 = atoi(args[2]);
  L1 = atoi(args[3]);


  Kokkos::initialize(narg,args);

  Kokkos::View<double*,Kokkos::LayoutRight> a("Data",N), b("Data",N);

  for(int i = 0; i<N ; i++) 
  {
	a[i] = (double)(i%10) / M_PI;
	b[i] = (double)((i%100) + 1)   / M_PI;
  }

  const Kokkos::TeamPolicy<> policy( L0 , L1, WARP_SIZE);

  struct timeval  tv1, tv2;
  gettimeofday(&tv1, NULL);

  Kokkos::parallel_for( policy , SomeCorrelation<double>(a,b, L0 , N) );

  Kokkos::fence();

  gettimeofday(&tv2, NULL);
  double exec_time = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);

  //for(int i = 0; i<N ; i++)
//	printf("%0.2f ", a[i]);
	printf("\n\na[N-1],N, L0, L1, vector_length, exec_time:\t9_POOL_and_SUB_VIEW\t%0.2f\t%d\t%d\t%d\t%d\t%f\n",a[N-1],N, L0, L1, 1, exec_time);

  printf("\n");
  Kokkos::finalize();
}

