//~/installs/Trilinos/install/opt_simd/bin/nvcc_wrapper -std=c++11 -I/ascldap/users/drsahas/installs/value_typerilinos/install/opt_simd/include/ -L/home/drsahas/installs/value_typerilinos/install/opt_simd/lib -lkokkoscore cuda_example.cpp
#include <sys/time.h>
#include <Kokkos_Core.hpp>
#include <cstdio>
#define WARP_SIZE 32

int N , M, L0 , L1;


typedef typename Kokkos::TeamPolicy<>::member_type team_member ;

template <typename value_type>
class Vector	//class to be instantiated inside parallel region. 
{
public:
	KOKKOS_INLINE_FUNCTION Vector(double a) : m_thread_val(a) {}
	//-------------------------------------- operator = --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator= (Vector& a)	{
	  m_thread_val = a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator= (value_type a) {
	  m_thread_val = a;
	  return *this;
	}

	//-------------------------------------- operator += and + --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator+= (Vector& a) {
	  m_thread_val += a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator+= (value_type a)	{
	  m_thread_val += a;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION value_type operator+ (Vector& a)	{ return (m_thread_val + a.m_thread_val); }

	KOKKOS_INLINE_FUNCTION value_type operator+ (value_type a)	{ return (m_thread_val + a); }


	//-------------------------------------- operator *= and * --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator*= (Vector& a) {
	  m_thread_val *= a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator*= (value_type a)	{
	  m_thread_val *= a;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION value_type operator* (Vector& a)	{ return (m_thread_val * a.m_thread_val); }

	KOKKOS_INLINE_FUNCTION value_type operator* (value_type a)	{ return (m_thread_val * a); }


	//-------------------------------------- operator -= and - --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator-= (Vector& a) {
	  m_thread_val -= a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator-= (value_type a)	{
	  m_thread_val -= a;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION value_type operator- (Vector& a)	{ return (m_thread_val - a.m_thread_val); }

	KOKKOS_INLINE_FUNCTION value_type operator- (value_type a)	{ return (m_thread_val - a); }


	//-------------------------------------- operator /= and / --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator/= (Vector& a) {
	  m_thread_val /= a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator/= (value_type a)	{
	  m_thread_val /= a;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION value_type operator/ (Vector& a)	{ return (m_thread_val / a.m_thread_val); }

	KOKKOS_INLINE_FUNCTION value_type operator/ (value_type a)	{ return (m_thread_val / a); }

 	
//private: 
	value_type m_thread_val; 	//value_typehere will be WARP_SIZE instances of this class. Each instance stores a single value corresponding to it's vector lane i.e. threadIdx.x. 
};

template <typename value_type> KOKKOS_INLINE_FUNCTION value_type operator+(value_type a, Vector<value_type>& n) { return (n + a); }	//if first operand is double and second is Vector

template <typename value_type> KOKKOS_INLINE_FUNCTION value_type operator-(value_type a, Vector<value_type>& n) { return (n - a); }	//if first operand is double and second is Vector

template <typename value_type> KOKKOS_INLINE_FUNCTION value_type operator*(value_type a, Vector<value_type>& n) { return (n * a); }	//if first operand is double and second is Vector

template <typename value_type> KOKKOS_INLINE_FUNCTION value_type operator/(value_type a, Vector<value_type>& n) { return (n / a); }	//if first operand is double and second is Vector


namespace Kokkos {

template< class value_type, class ... Properties >
class SimdView : public View<value_type*, Properties...>
{
	public:
	SimdView() {}
	template <class T, class ...A>SimdView(T data, A ...args ) : View<value_type*, Properties...>(data, WARP_SIZE, args...) {}

	typedef typename View<value_type*, Properties...>::reference_type reference_type;	//same as View operator

	template<class ...I> KOKKOS_INLINE_FUNCTION 
	reference_type operator()(I ...i) const	//I0 always offseted by vector lane. i1 onwards to be passed on to View.
	{
		return View<value_type*, Properties...>::operator()(threadIdx.x, i...);
	}
};

};

template <typename value_type>
struct SomeCorrelation
{
	typedef Kokkos::SimdView<Vector<value_type>**,Kokkos::LayoutLeft, Kokkos::MemoryTraits<Kokkos::Unmanaged>> simd_view;
	typedef Kokkos::View<value_type***,Kokkos::LayoutLeft> plain_view;

	simd_view A, B, C;
	int rows, N, M;

  	SomeCorrelation(plain_view a, plain_view b, plain_view c, int L0 , int N1, int M1):N(N1), M(M1)
	{
		A = simd_view(reinterpret_cast<Vector<value_type>*>(a.data()), N, N);
		B = simd_view(reinterpret_cast<Vector<value_type>*>(b.data()), N, N);
		C = simd_view(reinterpret_cast<Vector<value_type>*>(c.data()), N, N);
		rows = N / L0;	//rows per team
	}

	KOKKOS_INLINE_FUNCTION void operator() ( const team_member & thread) const 
	{
		int rb = thread.league_rank() * rows; //starting row
		Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, rows), [&] (const int& row)  //rows loop
		{
			int i = rb + row; 
			if(i < N)
				for(int j = 0; j<N ; j++) 	//columns loop
					for(int k = 0; k<N ; k++) 	//columns loop
								C(j, i) += A(k, i)*B(k, j);	//using b(m, k, j) instead of b(m, j, k) because of transpose

		});
	}
};

void printView(Kokkos::View<double***,Kokkos::LayoutLeft> a)
{
printf("\n\n\n");
  for(int m = 0; m<M ; m++)	//m for matrix
  {
	  for(int i = 0; i<N ; i++) 
	  {
		for(int j = 0; j<N ; j++) 
			printf("%0.f\t", a(j, i, m));
		printf("\n");
	  }
	printf("-----------\n");
  }
}

void printViewT(Kokkos::View<double***,Kokkos::LayoutLeft> a)
{
printf("\n\n\n");
	for(int i = 0; i<N ; i++) 
	{
		for(int j = 0; j<N ; j++) 
		{
			for(int m = 0; m<M ; m++)	//m for matrix
				printf("%0.f\t", a(m, j, i));
			printf("\n");
		}
		printf("-----------\n");
	}
}


int main(int narg, char* args[]) {
  N = atoi(args[1]);
  M = atoi(args[2]);
  L0 = atoi(args[3]);
  L1 = atoi(args[4]);

  Kokkos::initialize(narg,args);

  Kokkos::View<double***,Kokkos::LayoutRight> a("mat_A",N,N,M), b("mat_B",N,N,M), c("mat_C",N,N,M);
  Kokkos::View<double***,Kokkos::LayoutLeft>  at("mat_AT",M,N,N), bt("mat_BT",M,N,N), ct("mat_CT",M,N,N);

//init
#pragma omp parallel for
  for(int m = 0; m<M ; m++)	//m for matrix
	  for(int i = 0; i<N ; i++) 
		for(int j = 0; j<N ; j++) 
		{
			a(j, i, m)=i*N + j;
			b(j, i, m)=1.0;
			ct(j, i, m)=0.0;
		}
//printView(b);

//transpose
#pragma omp parallel for
  for(int m = 0; m<M ; m++)	//m for matrix
	  for(int i = 0; i<N ; i++) 
		for(int j = 0; j<N ; j++) 
		{
			bt(m, i, j) = b(j, i, m);	//take b transpose and also bring matrix dim to first dim. 
			at(m, j, i) = a(j, i, m);	//rearrange a to bring matrix dim to first dim
		}
  //printViewT(at);


//kernel
  printf("starting kernel\n");
  const Kokkos::TeamPolicy<> policy( L0 , L1, WARP_SIZE);

  struct timeval  tv1, tv2;
  gettimeofday(&tv1, NULL);

  Kokkos::parallel_for( policy , SomeCorrelation<double>(at, bt, ct, L0 , N, M) );

  Kokkos::fence();

  gettimeofday(&tv2, NULL);
  double exec_time = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);

  printf("kernel completed, verifying\n");

//rearrange c to individual matrices
#pragma omp parallel for
  for(int m = 0; m<M ; m++)	//m for matrix
	  for(int i = 0; i<N ; i++) 
		for(int j = 0; j<N ; j++) 
			c(j, i, m) = ct(m, j, i);	


//verify
#pragma omp parallel for
  for(int m = 0; m<M ; m++)	//m for matrix
	  for(int i = 0; i<N ; i++) 
	  {
		for(int j = 0; j<N ; j++) 
		{
			double temp = 0.0;
			for(int k = 0; k<N ; k++) 
			{
				temp += a(k, i, m)*b(j, k, m);
			}
			//printf("%0.f\t", temp);
			if(c(j, i, m) != temp)
			{
				printf("\n\n-----------error-----------\n\n");
				exit(1);
			}
		}
		//printf("\n");
	  }

	//printView(c);
	//printViewT(ct);
	
	printf("\n\nSuccess: N, L0, L1, vector_length, exec_time:\t15_cuda_gemm\t%d\t%d\t%d\t%d\t%f\n", N, L0, L1, 1, exec_time);

  printf("\n");

  Kokkos::finalize();
}

