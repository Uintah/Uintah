//~/installs/Trilinos/install/opt_simd/bin/nvcc_wrapper -std=c++11 -I/ascldap/users/drsahas/installs/Trilinos/install/opt_simd/include/ -L/home/drsahas/installs/Trilinos/install/opt_simd/lib -lkokkoscore cuda_example.cpp

#include <Kokkos_Core.hpp>
#include <KokkosKernels_Uniform_Initialized_MemoryPool.hpp>
#include <cstdio>
#define WARP_SIZE 32
#define NUM_OF_CHUNKS 4
int N , L0 , L1;

typedef Kokkos::Cuda::memory_space cudaspace;
typedef KokkosKernels::Impl::UniformMemoryPool<cudaspace, double> mem_pool_type;
typedef typename Kokkos::TeamPolicy<>::member_type team_member ;

__device__ mem_pool_type *dev_mem_pool=NULL;


template <typename value_type, int vector_length=1> class Vector;

template <typename value_type, int vector_length=1>
struct SIMD	//need to use different structs for data field in Vector class and for temp data. temp data comes from pool dynamically, while data element of Vector should have fixed length to cast
{
	value_type data[vector_length];
};

template <typename value_type, int vector_length=1>
struct temp_data
{
	value_type *data;
	__host__ __device__  temp_data(int index)
	{
		data = dev_mem_pool->allocate_chunk(index);
		if(!data)
			printf("pool out of memory \n");
	}

	__host__ __device__  ~temp_data()
	{
		release_temp_data();
	}
	__host__ __device__ inline void  release_temp_data()
	{
		if(data)
			dev_mem_pool->release_arbitrary_chunk(data);
		data=NULL;
	}

	__host__ __device__ inline temp_data operator+(Vector<value_type, vector_length>& n)	//(a+b) + c
	{
	    return (n + *this);
	}

	__host__ __device__ inline temp_data operator+(temp_data a)		//case such as  (a+b) + (c+d)
	{
	    for(int i=0; i<vector_length; i++)
		data[i] += a.data[i];
	    a.release_temp_data();
	    return *this;
	}
};

template <typename value_type, int vector_length>
class Vector	//class to be instantiated inside parallel region. 
{
public:
	
	__host__ __device__ inline Vector operator+= (const Vector& a)	//a+=b
	{
	  for(int i=0; i<vector_length; i++)
	    m_thread_val.data[i] += a.m_thread_val.data[i];
	  return *this;
	}

	__host__ __device__ inline Vector operator+= (temp_data<value_type, vector_length> a)	//a+=b+c
	{
	  for(int i=0; i<vector_length; i++)
	    m_thread_val.data[i] += a.data[i];
	  a.release_temp_data();	//need to explicitely release chunk to memory pool to recycle for next operation in chain. Its seems destructor is called at the end of entire operation and we run out of pool
	  return *this;
	}

	__host__ __device__ inline temp_data<value_type, vector_length> operator+ (const Vector& a)	//a+b
	{
	  int threadsPerBlock  = blockDim.x * blockDim.y * blockDim.z;
	  int threadNumInBlock = blockDim.x * blockDim.y * threadIdx.z + blockDim.x * threadIdx.y + threadIdx.x;
	  int blockNumInGrid   = gridDim.y * gridDim.x * blockIdx.z  + gridDim.x * blockIdx.y + blockIdx.x;
	  int globalThreadNum = blockNumInGrid * threadsPerBlock + threadNumInBlock;
	  temp_data<value_type, vector_length> temp(NUM_OF_CHUNKS * globalThreadNum);	//multiply by NUM_OF_CHUNKS to reduce invading temp space of other threads

	  for(int i=0; i<vector_length; i++)
 	    temp.data[i] = m_thread_val.data[i] + a.m_thread_val.data[i];
	  return temp;
	}

	__host__ __device__ inline temp_data<value_type, vector_length> operator+ (temp_data<value_type, vector_length> a)	//a+b+c
	{
	  int threadsPerBlock  = blockDim.x * blockDim.y * blockDim.z;
	  int threadNumInBlock = blockDim.x * blockDim.y * threadIdx.z + blockDim.x * threadIdx.y + threadIdx.x;
	  int blockNumInGrid   = gridDim.y * gridDim.x * blockIdx.z  + gridDim.x * blockIdx.y + blockIdx.x;
	  int globalThreadNum = blockNumInGrid * threadsPerBlock + threadNumInBlock;
	  temp_data<value_type, vector_length> temp(NUM_OF_CHUNKS * globalThreadNum);	//multiply by NUM_OF_CHUNKS to reduce invading temp space of other threads


	  for(int i=0; i<vector_length; i++)
 	    temp.data[i] = m_thread_val.data[i] + a.data[i];	
	  a.release_temp_data();
 	  return temp;
	}

	__host__ __device__ inline Vector operator= (const Vector& a)	//a=b
	{
	  for(int i=0; i<vector_length; i++)
	    m_thread_val.data[i] = a.m_thread_val.data[i];
	  return *this;
	}

	__host__ __device__ inline Vector operator= (temp_data<value_type, vector_length> a)	//a=b+c
	{
	  for(int i=0; i<vector_length; i++)
	    m_thread_val.data[i] = a.data[i];
	  a.release_temp_data();
	  return *this;
	}

private: 

	SIMD <value_type, vector_length> m_thread_val; 	//There will be WARP_SIZE instances of this class. Each instance stores a single value corresponding to it's vector lane i.e. threadIdx.x. 
};


template<typename value_type, int vector_length=1 >
struct SomeCorrelation 
{
  Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > A, B;
  mem_pool_type mem_pool;
  int loop_count, N;
  SomeCorrelation(mem_pool_type mem_pool,
		  Kokkos::View<value_type*,Kokkos::LayoutRight> a,
                  Kokkos::View<value_type*,Kokkos::LayoutRight> b, int L0 , int N
		 ):N(N), mem_pool(mem_pool)
		{
			Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > A1(reinterpret_cast<Vector<value_type, vector_length>*>(a.data()));
			Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > B1(reinterpret_cast<Vector<value_type, vector_length>*>(b.data()));
			A = A1;
			B = B1;
			N = N/vector_length;	//reinterpret_cast groups doubles into SIMD i.e. array of double[vector_length]. Hence divide N by vector_length
			loop_count = N/L0/WARP_SIZE;	//loop count N/L0 -> total N iterations divided among L0 teams. Again divid by WARP_SIZE. Kokkos will further divide this among L1 threads.
			if(loop_count==0 && N>0)	//if loop_count becomes 0 (when N < L0*WARP_SIZE i.e. all iterations can be accomodated by vectors of single thread) set lopp_count = 1
				loop_count=1;	

		}

  KOKKOS_INLINE_FUNCTION
  void operator() ( const team_member & thread) const 
  {
	if(dev_mem_pool==NULL)
		dev_mem_pool = (mem_pool_type *)&mem_pool;
	
	int i = thread.league_rank();
	Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, loop_count), [&] (const int& j) 	
	{
		
		
		int index = i*loop_count*WARP_SIZE + j*WARP_SIZE + threadIdx.x;	//dont use vector_length in loop_count and index calcs.during reinterpret_cast, N already is divided by vector_length.
		
		if(index < N)
		{
			A(index) += (A(index) + ((B(index) + A(index)) + B(index))) + (B(index) + B(index)) + (A(index) + ((B(index) + A(index)) + B(index))) + (B(index) + B(index)) + A(index);
			
			//A(index) = (A(index) + A(index)) + (B(index) + B(index)) + (A(index) + B(index));
		}
		/*Kokkos::parallel_for(Kokkos::ThreadVectorRange(thread, WARP_SIZE), [&] (const int& k) 
		{
			int index = i*loop_count*WARP_SIZE + j*WARP_SIZE + k;
			if(index < N)
			{
				A(index) += B(index);
				printf("team: %d %d, ijk: %d %d %d, threadIdx: %d %d %d blockIdx: %d %d %d, A,B: %f %f\n", thread.league_rank(), thread.team_rank(),i, j, k, 
				threadIdx.z, threadIdx.y, threadIdx.x, blockIdx.z, blockIdx.y, blockIdx.x, A(index) , B(index));
			}
		});*/
	});

  }
};

int main(int narg, char* args[]) {
  N = atoi(args[1]);
  L0 = atoi(args[2]);
  L1 = atoi(args[3]);


  Kokkos::initialize(narg,args);

  Kokkos::View<double*,Kokkos::LayoutRight> a("Data",N), b("Data",N);

  

  for(int i = 0; i<N ; i++) 
  {
	a[i] = (double)i;
	b[i] = (double)1;
  }

  const Kokkos::TeamPolicy<> policy( L0 , L1, WARP_SIZE);

  int num_chunks = L0 * L1 * WARP_SIZE * NUM_OF_CHUNKS;

  mem_pool_type mem_pool(num_chunks, 2, 0,  KokkosKernels::Impl::ManyThread2OneChunk);

  Kokkos::parallel_for( policy , SomeCorrelation<double, 2>(mem_pool, a,b, L0 , N) );

  Kokkos::fence();

  for(int i = 0; i<N ; i++)
	printf("%0.f ",a[i]);

  printf("\n");
  Kokkos::finalize();
}

