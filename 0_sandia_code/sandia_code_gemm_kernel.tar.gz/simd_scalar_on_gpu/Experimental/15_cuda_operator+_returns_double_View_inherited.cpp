//~/installs/Trilinos/install/opt_simd/bin/nvcc_wrapper -std=c++11 -I/ascldap/users/drsahas/installs/value_typerilinos/install/opt_simd/include/ -L/home/drsahas/installs/value_typerilinos/install/opt_simd/lib -lkokkoscore cuda_example.cpp
#include <sys/time.h>
#include <Kokkos_Core.hpp>
#include <cstdio>
#define WARP_SIZE 32

int N , L0 , L1;


typedef typename Kokkos::TeamPolicy<>::member_type team_member ;

template <typename value_type>
class Vector	//class to be instantiated inside parallel region. 
{
public:
	KOKKOS_INLINE_FUNCTION Vector(double a) : m_thread_val(a) {}
	//-------------------------------------- operator = --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator= (Vector& a)	{
	  m_thread_val = a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator= (value_type a) {
	  m_thread_val = a;
	  return *this;
	}

	//-------------------------------------- operator += and + --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator+= (Vector& a) {
	  m_thread_val += a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator+= (value_type a)	{
	  m_thread_val += a;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION value_type operator+ (Vector& a)	{ return (m_thread_val + a.m_thread_val); }

	KOKKOS_INLINE_FUNCTION value_type operator+ (value_type a)	{ return (m_thread_val + a); }


	//-------------------------------------- operator *= and * --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator*= (Vector& a) {
	  m_thread_val *= a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator*= (value_type a)	{
	  m_thread_val *= a;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION value_type operator* (Vector& a)	{ return (m_thread_val * a.m_thread_val); }

	KOKKOS_INLINE_FUNCTION value_type operator* (value_type a)	{ return (m_thread_val * a); }


	//-------------------------------------- operator -= and - --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator-= (Vector& a) {
	  m_thread_val -= a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator-= (value_type a)	{
	  m_thread_val -= a;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION value_type operator- (Vector& a)	{ return (m_thread_val - a.m_thread_val); }

	KOKKOS_INLINE_FUNCTION value_type operator- (value_type a)	{ return (m_thread_val - a); }


	//-------------------------------------- operator /= and / --------------------------------------------------------

	KOKKOS_INLINE_FUNCTION Vector operator/= (Vector& a) {
	  m_thread_val /= a.m_thread_val;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION Vector operator/= (value_type a)	{
	  m_thread_val /= a;
	  return *this;
	}

	KOKKOS_INLINE_FUNCTION value_type operator/ (Vector& a)	{ return (m_thread_val / a.m_thread_val); }

	KOKKOS_INLINE_FUNCTION value_type operator/ (value_type a)	{ return (m_thread_val / a); }

 	
private: 
	value_type m_thread_val; 	//value_typehere will be WARP_SIZE instances of this class. Each instance stores a single value corresponding to it's vector lane i.e. threadIdx.x. 
};

template <typename value_type> KOKKOS_INLINE_FUNCTION value_type operator+(value_type a, Vector<value_type>& n) { return (n + a); }	//if first operand is double and second is Vector

template <typename value_type> KOKKOS_INLINE_FUNCTION value_type operator-(value_type a, Vector<value_type>& n) { return (n - a); }	//if first operand is double and second is Vector

template <typename value_type> KOKKOS_INLINE_FUNCTION value_type operator*(value_type a, Vector<value_type>& n) { return (n * a); }	//if first operand is double and second is Vector

template <typename value_type> KOKKOS_INLINE_FUNCTION value_type operator/(value_type a, Vector<value_type>& n) { return (n / a); }	//if first operand is double and second is Vector


namespace Kokkos {

template< class value_type, class ... Properties >
class SimdView : public View<value_type, Properties...>
{
	public:
	template <class ...A>SimdView(A ...args ) : View<value_type, Properties...>(args...) {}

	typedef typename View<value_type, Properties...>::reference_type reference_type;	//same as View operator

	template<class I0, class ...I1> KOKKOS_INLINE_FUNCTION 
	reference_type operator()(I0 i0, I1 ...i1) const	//I0 always offseted by vector lane. i1 onwards to be passed on to View.
	{
		int index0 = i0*WARP_SIZE + threadIdx.x;
		return View<value_type, Properties...>::operator()(index0, i1...);
	}
};

};

template <typename value_type>
struct SomeCorrelation
{
  typedef Kokkos::SimdView<Vector<value_type>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged>> simd_view;
  simd_view A, B;
  int loop_count, N;
  SomeCorrelation(Kokkos::View<value_type*,Kokkos::LayoutRight> a,
                  Kokkos::View<value_type*,Kokkos::LayoutRight> b, int L0 , int N1
		 ):N(N1)
		{
			simd_view A1(reinterpret_cast<Vector<value_type>*>(a.data()));
			simd_view B1(reinterpret_cast<Vector<value_type>*>(b.data()));
			A = A1;
			B = B1;
			N = N / WARP_SIZE;
			loop_count = N/L0;	//loop count N/L0 -> total N iterations divided among L0 teams. Again divid by WARP_SIZE. Kokkos will further divide this among L1 threads.
			if(loop_count==0 && N>0)	//if loop_count becomes 0 (when N < L0*WARP_SIZE i.e. all iterations can be accomodated by vectors of single thread) set lopp_count = 1
				loop_count=1;	
		}

  KOKKOS_INLINE_FUNCTION
  void operator() ( const team_member & thread) const 
  {
	int i = thread.league_rank();
	Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, loop_count), [&] (const int& j) 	
	{
		int index = i*loop_count + j;
		//printf("\n %d\t%d\t%d", threadIdx.x, index, N);
		if(index < N)
		{
			for(int ii=0; ii<1000; ii++)
			{
				Vector<value_type> X = A(index) + B(index);
				A(index) /= (A(index) + (X + B(index))) + (B(index) + B(index));
				A(index) += (A(index) + ((B(index) - A(index)) + B(index))) + (B(index) + B(index)) + (A(index) / (X + B(index))) - (B(index) + B(index)) + A(index);			
				A(index) *= (B(index) + B(index)) + (B(index) + B(index));
				A(index) -= (B(index)/B(index));				
			}
		}
	});
  }
};

int main(int narg, char* args[]) {
  N = atoi(args[1]);
  L0 = atoi(args[2]);
  L1 = atoi(args[3]);


  Kokkos::initialize(narg,args);

  Kokkos::View<double*,Kokkos::LayoutRight> a("Data",N), b("Data",N);

  for(int i = 0; i<N ; i++) 
  {
	a[i] = (double)(i%10) / M_PI;
	b[i] = (double)((i%100) + 1)   / M_PI;
	//a[i]=i;
	//b[i]=1.0;
  }

  const Kokkos::TeamPolicy<> policy( L0 , L1, WARP_SIZE);

  struct timeval  tv1, tv2;
  gettimeofday(&tv1, NULL);

  Kokkos::parallel_for( policy , SomeCorrelation<double>(a,b, L0 , N) );

  Kokkos::fence();

  gettimeofday(&tv2, NULL);
  double exec_time = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);

  //for(int i = 0; i<N ; i++)
	//printf("%0.2f ", a[i]);
	printf("\n\na[N-1],N, L0, L1, vector_length, exec_time:\t9_POOL_and_SUB_VIEW\t%0.2f\t%d\t%d\t%d\t%d\t%f\n",a[N-1],N, L0, L1, 1, exec_time);

  printf("\n");
  Kokkos::finalize();
}

