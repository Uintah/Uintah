//~/installs/Trilinos/install/opt_simd/bin/nvcc_wrapper -std=c++11 -I/ascldap/users/drsahas/installs/Trilinos/install/opt_simd/include/ -L/home/drsahas/installs/Trilinos/install/opt_simd/lib -lkokkoscore cuda_example.cpp

#include <Kokkos_Core.hpp>
#include <cstdio>
#define WARP_SIZE 32
int N , L0 , L1;


typedef typename Kokkos::TeamPolicy<>::member_type team_member ;

class Double
{
public:

    __host__ __device__ Double(){}
    __host__ __device__ Double(double * data):m_data(data), m_thread_val(data[threadIdx.x]) {}    //m_thread_val stores data belonging to own "vector lane"

    __host__ __device__ inline Double operator+= (const Double& a)
    {
       //if(threadIdx.x==0) printf("%s %d\n",__FUNCTION__, __LINE__);
      int k=threadIdx.x;
      m_thread_val += a.m_thread_val;
      m_data[k] = m_thread_val;
      return *this;
    }

    __host__ __device__ inline Double operator+ (const Double& a)
    {
       //if(threadIdx.x==0) printf("%s %d\n",__FUNCTION__, __LINE__);
      Double n;
      n.m_thread_val = m_thread_val + a.m_thread_val;
      return n;

    }
    
    __host__ __device__ inline Double operator= (const Double& a)
    {
       //if(threadIdx.x==0) printf("%s %d\n",__FUNCTION__, __LINE__);
      int k=threadIdx.x;
      m_data[k] = a.m_thread_val;
      return *this;
    }
    

private:
    double m_thread_val; //downside - MUST be called within parallel region
    double * m_data;    
};

struct SomeCorrelation
{
  Kokkos::View<double*,Kokkos::LayoutRight> A, B;
  int loop_count, N;
  SomeCorrelation(Kokkos::View<double*,Kokkos::LayoutRight> a,
                  Kokkos::View<double*,Kokkos::LayoutRight> b, int L0 , int N
         ):A(a),B(b), N(N)
        {
            loop_count = N/L0/WARP_SIZE;    //loop count N/L0 -> total N iterations divided among L0 teams. Again divid by WARP_SIZE. Kokkos will further divide this among L1 threads.
	    if(loop_count==0 && N>0)	//if loop_count becomes 0 (when N < L0*WARP_SIZE i.e. all iterations can be accomodated by vectors of single thread) set lopp_count = 1
		loop_count=1;	
        }

  KOKKOS_INLINE_FUNCTION
  void operator() ( const team_member & thread) const
  {
    int i = thread.league_rank();
    Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, loop_count), [&] (const int& j)     
    {
        int index = i*loop_count*WARP_SIZE + j*WARP_SIZE;

        if(index < N)
        {
            Double a(&A(index)), b(&B(index));
            //a += b;
            //Double c = a + (a + a) + b;
            //a = c;
            a += (a + ((b + a) + b)) + (b + b);
            
        }
        /*Kokkos::parallel_for(Kokkos::ThreadVectorRange(thread, WARP_SIZE), [&] (const int& k)
        {
            int index = i*loop_count*WARP_SIZE + j*WARP_SIZE + k;
            if(index < N)
            {
                A(index) += B(index);
                printf("team: %d %d, ijk: %d %d %d, threadIdx: %d %d %d blockIdx: %d %d %d, A,B: %f %f\n", thread.league_rank(), thread.team_rank(),i, j, k,
                threadIdx.z, threadIdx.y, threadIdx.x, blockIdx.z, blockIdx.y, blockIdx.x, A(index) , B(index));
            }
        });*/
    });

  }
};

int main(int narg, char* args[]) {
  N = atoi(args[1]);
  L0 = atoi(args[2]);
  L1 = atoi(args[3]);


  Kokkos::initialize(narg,args);

  Kokkos::View<double*,Kokkos::LayoutRight> a("Data",N), b("Data",N);

  for(int i = 0; i<N ; i++)
  {
    a[i] = (double)i;
    b[i] = (double)1;
  }

  const Kokkos::TeamPolicy<> policy( L0 , L1, WARP_SIZE);

  Kokkos::parallel_for( policy , SomeCorrelation(a,b, L0 , N) );

  Kokkos::fence();

  for(int i = 0; i<N ; i++)
    printf("%f ",a[i]);

  printf("\n");
  Kokkos::finalize();
}
