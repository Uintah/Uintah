//~/installs/Trilinos/install/opt_simd/bin/nvcc_wrapper -std=c++11 -I/ascldap/users/drsahas/installs/Trilinos/install/opt_simd/include/ -L/home/drsahas/installs/Trilinos/install/opt_simd/lib -lkokkoscore cuda_example.cpp

#include <Kokkos_Core.hpp>
#include <cstdio>
#define WARP_SIZE 32
int N , L0 , L1;


typedef typename Kokkos::TeamPolicy<>::member_type team_member ;

template <int vector_length=1> class Double;


template <int vector_length=1>
struct Double_data
{
	double data[vector_length];


	__host__ __device__ inline Double_data operator+(Double<vector_length>& n)	//(a+b) + c
	{
	    return (n + *this);
	}

	__host__ __device__ inline Double_data operator+(Double_data a)		//case such as  (a+b) + (c+d)
	{
	    for(int i=0; i<vector_length; i++)
		data[i] += a.data[i];
	    return *this;
	}


};


template <int vector_length>
class Double	//class to be instantiated inside parallel region. 
{
public:
	
	__host__ __device__ Double(double * data)
	:m_data		(data) 		//m_data stores pointer to original location in array. Used to store values back to array in operator= or +=
	{
	   for(int i=0, j=0; i<vector_length*WARP_SIZE; i=i+WARP_SIZE, j++)
		m_thread_val.data[j] = data[threadIdx.x+i]; 	//m_thread_val stores data belonging to own "vector lane"
	}	

	__host__ __device__ inline Double operator+= (const Double& a)	//a+=b
	{
	  for(int i=0, j=0; i<vector_length*WARP_SIZE; i=i+WARP_SIZE, j++)
	  {
	    m_thread_val.data[j] += a.m_thread_val.data[j];
	    m_data[threadIdx.x+i] = m_thread_val.data[j];
	  }
	  return *this;
	}

	__host__ __device__ inline Double operator+= (Double_data<vector_length> a)	//a+=b+c
	{
	  for(int i=0, j=0; i<vector_length*WARP_SIZE; i=i+WARP_SIZE, j++)
	  {
	    m_thread_val.data[j] += a.data[j];
	    m_data[threadIdx.x+i] = m_thread_val.data[j];
	  }
	  return *this;
	}

	__host__ __device__ inline Double_data<vector_length> operator+ (const Double& a)	//a+b
	{
	  Double_data<vector_length> temp;
	  for(int i=0; i<vector_length; i++)
 	    temp.data[i] = m_thread_val.data[i] + a.m_thread_val.data[i];
	  return temp;
	}

	__host__ __device__ inline Double_data<vector_length> operator+ (Double_data<vector_length> a)	//a+b+c
	{
	  for(int i=0; i<vector_length; i++)
 	    a.data[i] = m_thread_val.data[i] + a.data[i];	//a is passed by copy. so can be overwritten and returned safely. 
 	  return a;
	}

	__host__ __device__ inline Double operator= (const Double& a)	//a=b
	{
	  for(int i=0, j=0; i<vector_length*WARP_SIZE; i=i+WARP_SIZE, j++)
	    m_data[threadIdx.x+i] = a.m_thread_val.data[j];
	  return *this;
	}

	__host__ __device__ inline Double operator= (const Double_data<vector_length> a)	//a=b+c
	{
	  for(int i=0, j=0; i<vector_length*WARP_SIZE; i=i+WARP_SIZE, j++)
	  {
	    m_data[threadIdx.x+i] = a.data[j];
	  }
	  return *this;
	}


 	//__host__ __device__ inline double get_thread_val() const {return m_thread_val;}
private: 
	__host__ __device__ Double(){}

	Double_data <vector_length> m_thread_val; 	//There will be WARP_SIZE instances of this class. Each instance stores a single value corresponding to it's vector lane i.e. threadIdx.x. 
	double * m_data{NULL};	//stores address to base array
};



template<int vector_length=1>
struct SomeCorrelation 
{
  Kokkos::View<double*,Kokkos::LayoutRight> A, B;
  int loop_count, N;
  SomeCorrelation(Kokkos::View<double*,Kokkos::LayoutRight> a,
                  Kokkos::View<double*,Kokkos::LayoutRight> b, int L0 , int N
		 ):A(a),B(b), N(N)
		{
			loop_count = N/L0/WARP_SIZE/vector_length;	//loop count N/L0 -> total N iterations divided among L0 teams. Again divid by WARP_SIZE. Kokkos will further divide this among L1 threads.
			if(loop_count==0 && N>0)	//if loop_count becomes 0 (when N < L0*WARP_SIZE*vector_length i.e. all iterations can be accomodated by vectors of single thread) set lopp_count = 1
				loop_count=1;	
		}

  KOKKOS_INLINE_FUNCTION
  void operator() ( const team_member & thread) const 
  {
	int i = thread.league_rank();
	Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, loop_count), [&] (const int& j) 	
	{
		int index = i*loop_count*WARP_SIZE*vector_length + j*WARP_SIZE*vector_length;
		if(index < N)
		{
			Double<vector_length> a(&A(index));
			Double<vector_length> b(&B(index));
			a += (a + ((b + a) + b)) + (b + b);
			
		}
		/*Kokkos::parallel_for(Kokkos::ThreadVectorRange(thread, WARP_SIZE), [&] (const int& k) 
		{
			int index = i*loop_count*WARP_SIZE + j*WARP_SIZE + k;
			if(index < N)
			{
				A(index) += B(index);
				printf("team: %d %d, ijk: %d %d %d, threadIdx: %d %d %d blockIdx: %d %d %d, A,B: %f %f\n", thread.league_rank(), thread.team_rank(),i, j, k, 
				threadIdx.z, threadIdx.y, threadIdx.x, blockIdx.z, blockIdx.y, blockIdx.x, A(index) , B(index));
			}
		});*/
	});

  }
};

int main(int narg, char* args[]) {
  N = atoi(args[1]);
  L0 = atoi(args[2]);
  L1 = atoi(args[3]);


  Kokkos::initialize(narg,args);

  Kokkos::View<double*,Kokkos::LayoutRight> a("Data",N), b("Data",N);

  for(int i = 0; i<N ; i++) 
  {
	a[i] = (double)i;
	b[i] = (double)1;
  }

  const Kokkos::TeamPolicy<> policy( L0 , L1, WARP_SIZE);

  Kokkos::parallel_for( policy , SomeCorrelation<2>(a,b, L0 , N) );

  Kokkos::fence();

  for(int i = 0; i<N ; i++)
	printf("%f ",a[i]);

  printf("\n");
  Kokkos::finalize();
}

