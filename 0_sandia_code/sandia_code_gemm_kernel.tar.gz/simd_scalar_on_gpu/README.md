The latest code is present at:
https://gitlab-ex.sandia.gov/drsahas/simd_scalar_on_gpu/tree/master/poratable/07112018_latest

The latest report is located at:
https://gitlab-ex.sandia.gov/drsahas/simd_scalar_on_gpu/tree/master/Report_v1
