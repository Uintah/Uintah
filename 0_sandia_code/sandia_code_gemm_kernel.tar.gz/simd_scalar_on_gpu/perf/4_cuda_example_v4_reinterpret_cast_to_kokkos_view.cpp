//~/installs/Trilinos/install/opt_simd/bin/nvcc_wrapper -std=c++11 -I/ascldap/users/drsahas/installs/Trilinos/install/opt_simd/include/ -L/home/drsahas/installs/Trilinos/install/opt_simd/lib -lkokkoscore cuda_example.cpp
#include <sys/time.h>
#include <Kokkos_Core.hpp>
#include <cstdio>
#define WARP_SIZE 32
#define VECTOR_LENGTH 4

int N , L0 , L1;


//if class names or struct names or its field name are changed, then these macros should also be updated
//-------------------------------------- binary operator generalization --------------------------------------------------------

//---------------------------------------- operation by assignment e.g. +=, *= etc. --------------------------------------------
//a is Vector. op is operator
#define bin_op_by_assignment_simd(a, op)	\
  for(int i=0; i<vector_length; i++)	\
    m_thread_val.data[i] = m_thread_val.data[i] op a.m_thread_val.data[i];	\
  return *this;	

//a is SIMD<vector_length>. op is operator
#define bin_op_by_assignment_temp(a, op)	\
  for(int i=0; i<vector_length; i++)	\
    m_thread_val.data[i] = m_thread_val.data[i] op a.data[i];	\
  return *this;


//---------------------------------------- plain binary operation e.g. +, * etc. --------------------------------------------
//a is Vector. op is operator
#define bin_op_simd(a, op)	\
  SIMD<value_type, vector_length> temp;	\
  for(int i=0; i<vector_length; i++)	\
    temp.data[i] = m_thread_val.data[i] op a.m_thread_val.data[i];	\
  return temp;


//a is SIMD<vector_length>. op is operator
#define bin_op_temp(a, op)	\
  for(int i=0; i<vector_length; i++)	\
    a.data[i] = m_thread_val.data[i] op a.data[i];		\
  return a;	

//a is SIMD<vector_length>. op is operator
#define bin_op_temp_temp(a, op)	\
    for(int i=0; i<vector_length; i++)	\
	data[i] = data[i] op a.data[i];	\
    return *this;	



typedef typename Kokkos::TeamPolicy<>::member_type team_member ;

template <typename value_type, int vector_length=1> class Vector;


template <typename value_type, int vector_length=1>
struct SIMD
{
	value_type data[vector_length];
	

	//-------------------------------------- operator + --------------------------------------------------------

	__host__ __device__ inline SIMD operator+(Vector<value_type, vector_length>& n) { return (n + *this); }	//(a+b) + c
	
	__host__ __device__ inline SIMD operator+(SIMD a) { bin_op_temp_temp(a, +); }		//case such as  (a+b) + (c+d)
	
	//-------------------------------------- operator - --------------------------------------------------------

	__host__ __device__ inline SIMD operator-(Vector<value_type, vector_length>& n) { return (n - *this); }	//(a-b) - c
	
	__host__ __device__ inline SIMD operator-(SIMD a) { bin_op_temp_temp(a, -); }		//case such as  (a-b) - (c-d)
	
	//-------------------------------------- operator * --------------------------------------------------------

	__host__ __device__ inline SIMD operator*(Vector<value_type, vector_length>& n) { return (n * (*this)); }	//(a*b) * c
	
	__host__ __device__ inline SIMD operator*(SIMD a) { bin_op_temp_temp(a, *); }		//case such as  (a+b) * (c+d)

	//-------------------------------------- operator / --------------------------------------------------------

	__host__ __device__ inline SIMD operator/(Vector<value_type, vector_length>& n) { return (n / *this); }	//(a/b) / c
	
	__host__ __device__ inline SIMD operator/(SIMD a) { bin_op_temp_temp(a, /); }		//case such as  (a/b) / (c/d)
};


template <typename value_type, int vector_length>
class Vector	//class to be instantiated inside parallel region. 
{
public:
	//-------------------------------------- operator = --------------------------------------------------------
	__host__ __device__ inline Vector operator= (const Vector& a)	//a=b
	{
	  for(int i=0; i<vector_length; i++)
	    m_thread_val.data[i] = a.m_thread_val.data[i];
	  return *this;
	}

	__host__ __device__ inline Vector operator= (const SIMD<value_type, vector_length> a)	//a=b+c
	{
	  for(int i=0; i<vector_length; i++)
	    m_thread_val.data[i] = a.data[i];
	  return *this;
	}
	
	//-------------------------------------- operator += and + --------------------------------------------------------
	
	__host__ __device__ inline Vector operator+= (const Vector& a)	{  bin_op_by_assignment_simd(a, +); }  		//a+=b
	
	__host__ __device__ inline Vector operator+= (SIMD<value_type, vector_length> a) {  bin_op_by_assignment_temp(a, +); }		//a+=b+c

	__host__ __device__ inline SIMD<value_type, vector_length> operator+ (const Vector& a)	{ bin_op_simd(a, +); }		//a+b

	__host__ __device__ inline SIMD<value_type, vector_length> operator+ (SIMD<value_type, vector_length> a) { bin_op_temp(a, +); }	//a+b+c
	
	//-------------------------------------- operator -= and - --------------------------------------------------------
	
	__host__ __device__ inline Vector operator-= (const Vector& a)	{  bin_op_by_assignment_simd(a, -); }  		//a-=b
	
	__host__ __device__ inline Vector operator-= (SIMD<value_type, vector_length> a) {  bin_op_by_assignment_temp(a, -); }		//a-=b-c

	__host__ __device__ inline SIMD<value_type, vector_length> operator- (const Vector& a)	{ bin_op_simd(a, -); }		//a-b

	__host__ __device__ inline SIMD<value_type, vector_length> operator- (SIMD<value_type, vector_length> a) { bin_op_temp(a, -); }	//a-b-c


	//-------------------------------------- operator *= and * --------------------------------------------------------
	
	__host__ __device__ inline Vector operator*= (const Vector& a)	{  bin_op_by_assignment_simd(a, *); }  		//a*=b
	
	__host__ __device__ inline Vector operator*= (SIMD<value_type, vector_length> a) {  bin_op_by_assignment_temp(a, *); }		//a*=b*c

	__host__ __device__ inline SIMD<value_type, vector_length> operator* (const Vector& a)	{ bin_op_simd(a, *); }		//a*b

	__host__ __device__ inline SIMD<value_type, vector_length> operator* (SIMD<value_type, vector_length> a) { bin_op_temp(a, *); }	//a*b*c


	//-------------------------------------- operator /= and / --------------------------------------------------------
	
	__host__ __device__ inline Vector operator/= (const Vector& a)	{  bin_op_by_assignment_simd(a, /); }  		//a/=b
	
	__host__ __device__ inline Vector operator/= (SIMD<value_type, vector_length> a) {  bin_op_by_assignment_temp(a, /); }		//a/=b/c

	__host__ __device__ inline SIMD<value_type, vector_length> operator/ (const Vector& a)	{ bin_op_simd(a, /); }		//a/b

	__host__ __device__ inline SIMD<value_type, vector_length> operator/ (SIMD<value_type, vector_length> a) { bin_op_temp(a, /); }	//a/b/c

private: 
	SIMD <value_type, vector_length> m_thread_val; 	//There will be WARP_SIZE instances of this class. Each instance stores a single value corresponding to it's vector lane i.e. threadIdx.x. 
};



template<typename value_type, int vector_length=1>
struct SomeCorrelation 
{
  Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > A, B;

  int loop_count, N;
  SomeCorrelation(Kokkos::View<double*,Kokkos::LayoutRight> a,
                  Kokkos::View<double*,Kokkos::LayoutRight> b, int L0 , int N
		 ):N(N)
		{
			Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > A1(reinterpret_cast<Vector<value_type, vector_length>*>(a.data()));
			Kokkos::View< Vector<value_type, vector_length>*,Kokkos::LayoutRight, Kokkos::MemoryTraits<Kokkos::Unmanaged> > B1(reinterpret_cast<Vector<value_type, vector_length>*>(b.data()));
			A = A1;
			B = B1;
			N = N/vector_length;	//reinterpret_cast groups doubles into SIMD i.e. array of double[vector_length]. Hence divide N by vector_length
			loop_count = N/L0/WARP_SIZE;	//loop count N/L0 -> total N iterations divided among L0 teams. Again divid by WARP_SIZE. Kokkos will further divide this among L1 threads.
			if(loop_count==0 && N>0)	//if loop_count becomes 0 (when N < L0*WARP_SIZE i.e. all iterations can be accomodated by vectors of single thread) set lopp_count = 1
				loop_count=1;	
		}

  KOKKOS_INLINE_FUNCTION
  void operator() ( const team_member & thread) const 
  {
	
	int i = thread.league_rank();
	Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, loop_count), [&] (const int& j) 	
	{
		int index = i*loop_count*WARP_SIZE + j*WARP_SIZE + threadIdx.x;	//dont use vector_length in loop_count and index calcs.during reinterpret_cast, N already is divided by vector_length.
		
		if(index < N)
		{
			for(int ii=0; ii<1000; ii++)
			{
				A(index) /= (A(index) + ((B(index) + A(index)) + B(index))) + (B(index) + B(index));
				A(index) += (A(index) + ((B(index) - A(index)) + B(index))) + (B(index) + B(index)) + (A(index) / ((B(index) + A(index)) + B(index))) - (B(index) + B(index)) + A(index);
			
				A(index) *= (B(index) + B(index)) + (B(index) + B(index));
				A(index) -= (B(index)/B(index));
			}
		}

	});

  }
};

int main(int narg, char* args[]) {
  N = atoi(args[1]);
  L0 = atoi(args[2]);
  L1 = atoi(args[3]);


  Kokkos::initialize(narg,args);

  Kokkos::View<double*,Kokkos::LayoutRight> a("Data",N), b("Data",N);

  for(int i = 0; i<N ; i++) 
  {
	a[i] = (double)(i%10) / M_PI;
	b[i] = (double)((i%100) + 1)   / M_PI;
  }

  const Kokkos::TeamPolicy<> policy( L0 , L1, WARP_SIZE);

  struct timeval  tv1, tv2;
  gettimeofday(&tv1, NULL);

  Kokkos::parallel_for( policy , SomeCorrelation<double, VECTOR_LENGTH>(a,b, L0 , N) );

  Kokkos::fence();

  gettimeofday(&tv2, NULL);
  double exec_time = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);

  //for(int i = 0; i<N ; i++)
	printf("a[N-1],N, L0, L1, vector_length, exec_time:\t4_VECTOR_LENGTH\t%0.2f\t%d\t%d\t%d\t%d\t%f\n",a[N-1],N, L0, L1, VECTOR_LENGTH, exec_time);

  printf("\n");
  Kokkos::finalize();
}

