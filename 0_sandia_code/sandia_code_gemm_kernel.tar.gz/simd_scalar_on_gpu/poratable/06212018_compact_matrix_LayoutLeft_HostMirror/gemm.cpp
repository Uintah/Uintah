/*
3 modes of operation:
1. GPU on white:
	set DEFAULT_VECTOR_LENGTH=32 in gemm.cpp - corresponding to gpu WARP_SIZE
	use "typedef Kokkos::DefaultExecutionSpace KernelExecSpece;"
	compile with "make -gpu"

2. OpenMP (no GPU) on white:
	set DEFAULT_VECTOR_LENGTH=8 in gemm.cpp - corresponding to cpu vector length (assumed for now. 32 would also do.)
	use "typedef Kokkos::DefaultHostExecutionSpace KernelExecSpece;"
	compile with "make -gpu"

3. OpenMP on KNL on bowman:
	set DEFAULT_VECTOR_LENGTH=8 in gemm.cpp - corresponding to KNL vector length for double
	use "typedef Kokkos::DefaultExecutionSpace KernelExecSpece;"
	compile with "make -knl"

run as ./a.out <matrix size> <num of matrices> <teams> <threads>. 
As of now teams should be <= matrix size
Number of matrice should be multiple of DEFAULT_VECTOR_LENGTH

*/

//taking shortcut. Ideally DEFAULT_VECTOR_LENGTH should be defined in cpu and gpu.h with respective values.
//Here it VECTOR_LENGTH shold be defined which will override DEFAULT_VECTOR_LENGTH
// DEFAULT_VECTOR_LENGTH should be (and must be) defined before #include "simd_scalar.h". Its used in DEFAULT_VECTOR_LENGTH

#define DEFAULT_VECTOR_LENGTH 32

#include <utility>
#include "simd_scalar.h"

int N , M, L0 , L1;

typedef Kokkos::LayoutLeft KernelLayout;
//typedef Kokkos::LayoutRight KernelLayout;

//typedef Kokkos::DefaultHostExecutionSpace KernelExecSpece;
typedef Kokkos::DefaultExecutionSpace KernelExecSpece;

typedef typename Kokkos::TeamPolicy<KernelExecSpece>::member_type team_member ;


template <typename value_type>
struct Gemm
{
	typedef Kokkos::View<Vector<value_type>***,KernelLayout, KernelExecSpece> view_vectorized;
	typedef Kokkos::View<value_type***,KernelLayout, KernelExecSpece> plain_view;

	view_vectorized A, B, C;
	int mats, N, M, L0, L1;

  	Gemm(plain_view a, plain_view b, plain_view c, int l0 , int l1, int N1, int M1): L0(l0), L1(l1), N(N1), M(M1/DEFAULT_VECTOR_LENGTH)
	{
		printf("DEFAULT_VECTOR_LENGTH: %d, M: %d\n", DEFAULT_VECTOR_LENGTH, M);
		A = view_vectorized(reinterpret_cast<Vector<value_type>*>(a.data()),M,N,N);
		B = view_vectorized(reinterpret_cast<Vector<value_type>*>(b.data()),M,N,N);
		C = view_vectorized(reinterpret_cast<Vector<value_type>*>(c.data()),M,N,N);
		//rows = N / L0;	//rows per team
		mats = M / L0 / L1;	//mats per thread
		if(mats==0) mats = 1;	//assign at least 1 matrix
	}

	KOKKOS_INLINE_FUNCTION void operator() ( const team_member & thread) const 
	{
		Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, L1), [&] (const int& l)
		{
			int thread_id = thread.league_rank() * L1 + l;
			int mb = thread_id * mats;
			int me = mb+mats;
			if(me <= M)
			{
				auto AA = Kokkos::subview(A, std::make_pair(mb,me), Kokkos::ALL(), Kokkos::ALL());
				auto BB = Kokkos::subview(B, std::make_pair(mb,me), Kokkos::ALL(), Kokkos::ALL());
				auto CC = Kokkos::subview(C, std::make_pair(mb,me), Kokkos::ALL(), Kokkos::ALL());

				for(int i = 0; i<N ; i++) 	//columns loop
				{
					for(int j = 0; j<N ; j++) 	//columns loop
					{
						//for(int m=0; m < mats; m++)
						//	BB(j, j, m).print();
						for(int k = 0; k<N ; k++) 	
						{
							//for(int m=mb; m < me; m++)
							//	C(i, j, m) += A(i, k, m)*B(j, k, m);	//using b(j, k, m) instead of b(k, j, m) because of transpose
							for(int m=0; m < mats; m++)
								CC(m, j, i) += AA(m, k, i, m)*BB(m, k, j);	//using b(j, k, m) instead of b(k, j, m) because of transpose
						}
						//Kokkos::parallel_for(Kokkos::ThreadVectorRange(thread, WARP_SIZE), [&] (const int& v) { if(v==0) printf("\n"); });			
					}
						//Kokkos::parallel_for(Kokkos::ThreadVectorRange(thread, WARP_SIZE), [&] (const int& v) { if(v==0) printf("\n"); });			
				}
			}
		});
	}

	/*KOKKOS_INLINE_FUNCTION void operator() ( const team_member & thread) const 
	{
		int rb = thread.league_rank() * rows; //starting row
		Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, rows), [&] (const int& row)  //rows loop
		{
			int i = rb + row; 
			if(i < N)
			{
				for(int j = 0; j<N ; j++) 	//columns loop
				{
					//PerVL<value_type, DEFAULT_VECTOR_LENGTH/WARP_SIZE> temp = 0.0;
					for(int k = 0; k<N ; k++) 	
					{
						for(int m=0; m < M; m++)
							C(m, j, i) += A(m, k, i)*B(m, k, j);	//using b(m, k, j) instead of b(m, j, k) because of transpose
					}
					//C(j, i) = temp;
				}
				//if(threadIdx.x==0) printf("\n");			
			}
		});
	}*/
};

void printView(Kokkos::View<double***,Kokkos::LayoutRight> a)
{
printf("\n\n\n");
  for(int m = 0; m<M ; m++)	//m for matrix
  {
	  for(int i = 0; i<N ; i++) 
	  {
		for(int j = 0; j<N ; j++) 
			printf("%0.f\t", a(m, i, j));
		printf("\n");
	  }
	printf("-----------\n");
  }
}

typedef typename Kokkos::View<double***,KernelLayout, KernelExecSpece>::HostMirror host_mirror;

void printViewT(host_mirror a)
{
printf("\n\n\n");
	for(int i = 0; i<N ; i++) 
	{
		for(int j = 0; j<N ; j++) 
		{
			for(int m = 0; m<M ; m++)	//m for matrix
				printf("%0.f\t", a(m, i, j));
			printf("\n");
		}
		printf("-----------\n");
	}
}


int main(int narg, char* args[]) {
  N = atoi(args[1]);
  M = atoi(args[2]);
  L0 = atoi(args[3]);
  L1 = atoi(args[4]);

  Kokkos::initialize(narg,args);
printf("kokkos init\n");
  Kokkos::View<double***,Kokkos::LayoutRight, Kokkos::DefaultHostExecutionSpace> a("mat_A",M,N,N), b("mat_B",M,N,N);
  Kokkos::View<double***,KernelLayout, KernelExecSpece> at("mat_AT",M,N,N), bt("mat_BT",M,N,N), ct("mat_CT",M,N,N);
  
  host_mirror a_hm = create_mirror_view(at);
  host_mirror b_hm = create_mirror_view(bt);
  host_mirror c_hm = create_mirror_view(ct);

printf("view allocated\n");

  /*typedef Kokkos::View<Vector<double>***,KernelLayout> view_vectorized;
  view_vectorized A(reinterpret_cast<Vector<double>*>(a.data()), N, N, M/DEFAULT_VECTOR_LENGTH);
  view_vectorized B(reinterpret_cast<Vector<double>*>(b.data()), N, N, M/DEFAULT_VECTOR_LENGTH);*/

//init:
Kokkos::parallel_for(Kokkos::RangePolicy<Kokkos::DefaultHostExecutionSpace>(0, M), [&](int m){	//m for matrix
	  for(int i = 0; i<N ; i++) 
		for(int j = 0; j<N ; j++) 
		{
			a(m, i, j)=i*N + j;
			b(m, i, j)=1.0;			
		}
	});
//printView(a);
printf("view init\n");
//transpose
Kokkos::parallel_for(Kokkos::RangePolicy<Kokkos::DefaultHostExecutionSpace>(0, N), [&](int i){
	for(int j = 0; j<N ; j++) 
		for(int m = 0; m<M ; m++)	//m for matrix
		{
			/*bt(i, j, m) = b(m, j, i);	//take b transpose and also bring matrix dim to first dim. 
			at(i, j, m) = a(m, i, j);	//rearrange a to bring matrix dim to first dim	
 			ct(i, j, m)=0.0;*/

			a_hm(m, i, j) = a(m, j, i);	// change m's dimension for compact layout. interchange i and j because its layoutleft on gpu and want to have coalesced access along columns
			b_hm(m, i, j) = b(m, i, j);	// change m's dimension for compact layout. do NOT interchange i and j because its layoutleft on gpu and want to have coalesced access along ROWs	
 			c_hm(m, i, j)=0.0;
	
		}
});
  //printViewT(a_hm);
  Kokkos::deep_copy(at, a_hm);
  Kokkos::deep_copy(bt, b_hm);
  Kokkos::deep_copy(ct, c_hm);

//kernel
  printf("starting kernel, getVectorLength(): %d\n", getVectorLength<KernelExecSpece>());
  
  const Kokkos::TeamPolicy<KernelExecSpece> policy( L0 , L1, getVectorLength<KernelExecSpece>());

  struct timeval  tv1, tv2;
  gettimeofday(&tv1, NULL);

  Kokkos::parallel_for( policy , Gemm<double>(at, bt, ct, L0, L1, N, M) );

  Kokkos::fence();

  gettimeofday(&tv2, NULL);
  double exec_time = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);

  printf("kernel completed, verifying\n");

  Kokkos::deep_copy(c_hm, ct);
//printViewT(c_hm);
//verify
Kokkos::parallel_for(Kokkos::RangePolicy<Kokkos::DefaultHostExecutionSpace>(0, M), [&](int m){
	  for(int i = 0; i<N ; i++) 
	  {
		for(int j = 0; j<N ; j++) 
		{
			double temp = 0.0;
			for(int k = 0; k<N ; k++) 
			{
				temp += a(m, i, k)*b(m, k, j);	//simple verification. no transpose, no compressed layout
			}

			if(c_hm(m, j, i) != temp)	//checking compressed matric. hence ct(i, j, m) and not ct(m, i, j)
			{
				printf("\n\n-----------error-----------\n\n");
				exit(1);
			}
		}
		//printf("\n");
	  }
});

	
	printf("\n\nSuccess: N, L0, L1, vector_length, exec_time:\t15_cuda_gemm\t%d\t%d\t%d\t%d\t%f\n", N, L0, L1, 1, exec_time);

  printf("\n");

  Kokkos::finalize();
}

