/*
3 modes of operation:
1. GPU on white:
	set DEFAULT_VECTOR_LENGTH=32 in gemm.cpp - corresponding to gpu WARP_SIZE
	use "typedef Kokkos::DefaultExecutionSpace KernelExecSpece;"
	compile with "make -gpu"

2. OpenMP (no GPU) on white:
	set DEFAULT_VECTOR_LENGTH=8 in gemm.cpp - corresponding to cpu vector length (assumed for now. 32 would also do.)
	use "typedef Kokkos::DefaultHostExecutionSpace KernelExecSpece;"
	compile with "make -gpu"

3. OpenMP on KNL on bowman:
	set DEFAULT_VECTOR_LENGTH=8 in gemm.cpp - corresponding to KNL vector length for double
	use "typedef Kokkos::DefaultExecutionSpace KernelExecSpece;"
	compile with "make -knl"

run as ./a.out <matrix size> <num of matrices> <teams> <threads>. 
As of now teams should be <= matrix size
Number of matrice should be multiple of DEFAULT_VECTOR_LENGTH

*/

//taking shortcut. Ideally DEFAULT_VECTOR_LENGTH should be defined in cpu and gpu.h with respective values.
//Here it VECTOR_LENGTH shold be defined which will override DEFAULT_VECTOR_LENGTH
// DEFAULT_VECTOR_LENGTH should be (and must be) defined before #include "simd_scalar.h". Its used in DEFAULT_VECTOR_LENGTH

#define DEFAULT_VECTOR_LENGTH 32

#include <utility>
#include "simd_scalar.h"

int N , M, L0 , L1;

typedef Kokkos::LayoutLeft KernelLayout;
//typedef Kokkos::LayoutRight KernelLayout;

typedef Kokkos::DefaultHostExecutionSpace KernelExecSpece;
//typedef Kokkos::DefaultExecutionSpace KernelExecSpece;

typedef typename Kokkos::TeamPolicy<KernelExecSpece>::member_type team_member ;


template <typename value_type>
struct Gemm
{
	typedef Kokkos::View<Vector<value_type>***,KernelLayout> view_vectorized;
	typedef Kokkos::View<value_type***,KernelLayout> plain_view;

	view_vectorized A, B, C;
	int mats, N, M, L0, L1;

  	Gemm(plain_view a, plain_view b, plain_view c, int l0 , int l1, int N1, int M1): L0(l0), L1(l1), N(N1), M(M1/DEFAULT_VECTOR_LENGTH)
	{
		printf("DEFAULT_VECTOR_LENGTH: %d, M: %d\n", DEFAULT_VECTOR_LENGTH, M);
		A = view_vectorized(reinterpret_cast<Vector<value_type>*>(a.data()), M, N, N);
		B = view_vectorized(reinterpret_cast<Vector<value_type>*>(b.data()), M, N, N);
		C = view_vectorized(reinterpret_cast<Vector<value_type>*>(c.data()), M, N, N);
		//rows = N / L0;	//rows per team
		mats = M / L0 / L1;	//mats per thread
		if(mats==0) mats = 1;	//assign at least 1 matrix
	}

	KOKKOS_INLINE_FUNCTION void operator() ( const team_member & thread) const 
	{
		Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, L1), [&] (const int& l)
		{
			int thread_id = thread.league_rank() * L1 + l;
			int mb = thread_id * mats;
			int me = mb+mats;
			if(me <= M)
			{
				auto AA = Kokkos::subview(A, std::make_pair(mb,me), Kokkos::ALL(), Kokkos::ALL());
				auto BB = Kokkos::subview(B, std::make_pair(mb,me), Kokkos::ALL(), Kokkos::ALL());
				auto CC = Kokkos::subview(C, std::make_pair(mb,me), Kokkos::ALL(), Kokkos::ALL());

				for(int i = 0; i<N ; i++) 	//columns loop
				{
					for(int j = 0; j<N ; j++) 	//columns loop
					{
						for(int k = 0; k<N ; k++) 	
						{
							//for(int m=mb; m < me; m++)
							//	C(m, j, i) += A(m, k, i)*B(m, k, j);	//using b(m, k, j) instead of b(m, j, k) because of transpose
							for(int m=0; m < mats; m++)
								CC(m, j, i) += AA(m, k, i)*BB(m, k, j);	//using b(m, k, j) instead of b(m, j, k) because of transpose
						}
					}
					//if(threadIdx.x==0) printf("\n");			
				}
			}
		});
	}

	/*KOKKOS_INLINE_FUNCTION void operator() ( const team_member & thread) const 
	{
		int rb = thread.league_rank() * rows; //starting row
		Kokkos::parallel_for(Kokkos::TeamThreadRange(thread, rows), [&] (const int& row)  //rows loop
		{
			int i = rb + row; 
			if(i < N)
			{
				for(int j = 0; j<N ; j++) 	//columns loop
				{
					//PerVL<value_type, DEFAULT_VECTOR_LENGTH/WARP_SIZE> temp = 0.0;
					for(int k = 0; k<N ; k++) 	
					{
						for(int m=0; m < M; m++)
							C(m, j, i) += A(m, k, i)*B(m, k, j);	//using b(m, k, j) instead of b(m, j, k) because of transpose
					}
					//C(j, i) = temp;
				}
				//if(threadIdx.x==0) printf("\n");			
			}
		});
	}*/
};

void printView(Kokkos::View<double***,Kokkos::LayoutRight> a)
{
printf("\n\n\n");
  for(int m = 0; m<M ; m++)	//m for matrix
  {
	  for(int i = 0; i<N ; i++) 
	  {
		for(int j = 0; j<N ; j++) 
			printf("%0.f\t", a(j, i, m));
		printf("\n");
	  }
	printf("-----------\n");
  }
}

void printViewT(Kokkos::View<double***,KernelLayout> a)
{
printf("\n\n\n");
	for(int i = 0; i<N ; i++) 
	{
		for(int j = 0; j<N ; j++) 
		{
			for(int m = 0; m<M ; m++)	//m for matrix
				printf("%0.f\t", a(m, j, i));
			printf("\n");
		}
		printf("-----------\n");
	}
}


int main(int narg, char* args[]) {
  N = atoi(args[1]);
  M = atoi(args[2]);
  L0 = atoi(args[3]);
  L1 = atoi(args[4]);

  Kokkos::initialize(narg,args);
printf("kokkos init\n");
  Kokkos::View<double***,Kokkos::LayoutRight> a("mat_A",N,N,M), b("mat_B",N,N,M), c("mat_C",N,N,M);
  Kokkos::View<double***,KernelLayout> at("mat_AT",M,N,N), bt("mat_BT",M,N,N), ct("mat_CT",M,N,N);
printf("view allocated\n");

  /*typedef Kokkos::View<Vector<double>***,KernelLayout> view_vectorized;
  view_vectorized A(reinterpret_cast<Vector<double>*>(a.data()), N, N, M/DEFAULT_VECTOR_LENGTH);
  view_vectorized B(reinterpret_cast<Vector<double>*>(b.data()), N, N, M/DEFAULT_VECTOR_LENGTH);*/

//init:
Kokkos::parallel_for(Kokkos::RangePolicy<Kokkos::DefaultHostExecutionSpace>(0, M), [&](int m){	//m for matrix
	  for(int i = 0; i<N ; i++) 
		for(int j = 0; j<N ; j++) 
		{
			a(j, i, m)=i*N + j;
			b(j, i, m)=1.0;			
		}
	});
//printView(a);
printf("view init\n");
//transpose
Kokkos::parallel_for(Kokkos::RangePolicy<Kokkos::DefaultHostExecutionSpace>(0, N), [&](int i){
	for(int j = 0; j<N ; j++) 
		for(int m = 0; m<M ; m++)	//m for matrix
		{
			bt(m, i, j) = b(j, i, m);	//take b transpose and also bring matrix dim to first dim. 
			at(m, j, i) = a(j, i, m);	//rearrange a to bring matrix dim to first dim	
 			ct(m, j, i)=0.0;
		}
});
  //printViewT(at);


//kernel
  printf("starting kernel, getVectorLength(): %d\n", getVectorLength<KernelExecSpece>());
  
  const Kokkos::TeamPolicy<KernelExecSpece> policy( L0 , L1, getVectorLength<KernelExecSpece>());

  struct timeval  tv1, tv2;
  gettimeofday(&tv1, NULL);

  Kokkos::parallel_for( policy , Gemm<double>(at, bt, ct, L0, L1, N, M) );

  Kokkos::fence();

  gettimeofday(&tv2, NULL);
  double exec_time = (double) (tv2.tv_usec - tv1.tv_usec) / 1000000 + (double) (tv2.tv_sec - tv1.tv_sec);

  printf("kernel completed, verifying\n");

//rearrange c to individual matrices
Kokkos::parallel_for(Kokkos::RangePolicy<Kokkos::DefaultHostExecutionSpace>(0, M), [&](int m){
	  for(int i = 0; i<N ; i++) 
		for(int j = 0; j<N ; j++) 
			c(j, i, m) = ct(m, j, i);	
});

	//printView(c);
	//printViewT(ct);

//verify
Kokkos::parallel_for(Kokkos::RangePolicy<Kokkos::DefaultHostExecutionSpace>(0, M), [&](int m){
	  for(int i = 0; i<N ; i++) 
	  {
		for(int j = 0; j<N ; j++) 
		{
			double temp = 0.0;
			for(int k = 0; k<N ; k++) 
			{
				temp += a(k, i, m)*b(j, k, m);
			}
			//printf("%0.f\t", temp);
			if(c(j, i, m) != temp)
			{
				printf("\n\n-----------error-----------\n\n");
				exit(1);
			}
		}
		//printf("\n");
	  }
});

	
	printf("\n\nSuccess: N, L0, L1, vector_length, exec_time:\t15_cuda_gemm\t%d\t%d\t%d\t%d\t%f\n", N, L0, L1, 1, exec_time);

  printf("\n");

  Kokkos::finalize();
}

