#include <sys/time.h>
#include <Kokkos_Core.hpp>
#include <typeinfo>

#define WARP_SIZE 32
#define CPU_VECTOR_LENGTH 8

template <typename T>
inline int getVectorLength()
{
	if(typeid(T) == typeid(Kokkos::DefaultHostExecutionSpace))
		return CPU_VECTOR_LENGTH;
	else
		return WARP_SIZE;
}





#ifdef __CUDA_ARCH__

	#include "gpu.h"

#else

	
	#ifdef __PPC__
		// if ibm power pc, include cpu.h which has generic (non simd definitions)
		#include "cpu.h"

	#else
		//for intel architectures, overload std::simd. Need to add specialization for all datatypes. May be fix vector length

		#include "stk_simd/Simd.hpp"
		template <typename value_type, int vector_length=DEFAULT_VECTOR_LENGTH>
		struct Vector;

		template <int vector_length>
		struct Vector<double, vector_length> : public stk::simd::Double
		{
			KOKKOS_INLINE_FUNCTION Vector operator= (double a)	{	//somehow direct call is not working, has to explicitely call
			  stk::simd::Double::operator=(a);
			  return *this;
			}	
		};

	#endif

#endif

