#include<Test_Serial.hpp>
#include<Test_Blas1_nrm2.hpp>
