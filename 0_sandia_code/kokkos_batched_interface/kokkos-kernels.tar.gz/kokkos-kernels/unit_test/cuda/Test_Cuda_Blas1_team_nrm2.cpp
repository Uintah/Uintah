#include<Test_Cuda.hpp>
#ifdef KOKKOS_ENABLE_CUDA_LAMBDA
#include<Test_Blas1_team_nrm2.hpp>
#endif
