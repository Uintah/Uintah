#include<Test_Cuda.hpp>
#include<Test_Blas1_reciprocal.hpp>
