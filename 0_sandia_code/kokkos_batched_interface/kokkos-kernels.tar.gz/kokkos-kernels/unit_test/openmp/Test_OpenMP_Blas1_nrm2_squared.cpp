#include<Test_OpenMP.hpp>
#include<Test_Blas1_nrm2_squared.hpp>
