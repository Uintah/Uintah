#ifndef SPARSEMATVEC_SIMD_H_
#define SPARSEMATVEC_SIMD_H_

#include <stdlib.h>


//added only bare minimum operators needed for spmv.

template <class value_type, int EL>	//PVL and LVL: Physical and logical vector lengths, EL: elements per vector lane
struct scalar_for_simd;


template <class value_type, int PVL, int LVL=PVL, int EL=LVL/PVL>	//PVL and LVL: Physical and logical vector lengths, EL: elements per vector lane
struct simd
{
	value_type d[LVL];

	typedef scalar_for_simd<value_type, EL> simd_scalar;

	__forceinline__ __host__ __device__ simd(){};
	//simd(const simd &a)=default;

	__forceinline__ __host__ __device__    simd& operator= (const simd &a) {
#pragma unroll(EL)
	  for(int i=0; i<EL; i++)
		  d[i*blockDim.x + threadIdx.x] = a.d[i*blockDim.x + threadIdx.x];
	  return *this;
	}


	__forceinline__ __host__ __device__    simd& operator= (const value_type &a) {
#pragma unroll(EL)
	  for(int i=0; i<EL; i++)
		  d[i*blockDim.x + threadIdx.x] = a;
	  return *this;
	}

	__forceinline__ __host__ __device__    simd& operator= (const simd_scalar &a) {
#pragma unroll(EL)
	  for(int i=0; i<EL; i++)
		  d[i*blockDim.x + threadIdx.x] = a.d[i];
	  return *this;
	}

	__forceinline__ __host__ __device__ simd_scalar operator*(const value_type &a)	//copy
	{
		simd_scalar temp;
#pragma unroll(EL)
		for(int i=0; i<EL; i++)
			temp.d[i] = d[i * blockDim.x + threadIdx.x] * a;

		return temp;
	}

	__forceinline__ __host__ __device__ simd& operator+=(const simd &a)
	{
#pragma unroll(EL)
		for(int i=0; i<EL; i++)
			d[i * blockDim.x + threadIdx.x] += a.d[i * blockDim.x + threadIdx.x];

		return *this;
	}

	__forceinline__ __host__ __device__ simd& operator+=(const simd_scalar &a)
	{
#pragma unroll(EL)
		for(int i=0; i<EL; i++)
			d[i * blockDim.x + threadIdx.x] += a.d[i];

		return *this;
	}
};


template <class value_type, int PVL=32, int LVL=32, int EL=LVL/PVL>
__forceinline__ __host__ __device__ scalar_for_simd<value_type, EL> operator*(const value_type &a, const simd<value_type, PVL, LVL, EL> &b)	//copy
{
	scalar_for_simd<value_type, EL> temp;
#pragma unroll(EL)
	for(int i=0; i<EL; i++)
		temp.d[i] = b.d[i * blockDim.x + threadIdx.x] * a;

	return temp;
}



template <class value_type, int EL>	//PVL and LVL: Physical and logical vector lengths, EL: elements per vector lane
struct scalar_for_simd
{
	value_type d[EL];

	__forceinline__ __host__ __device__ scalar_for_simd(){};
		scalar_for_simd(const scalar_for_simd &a)=default;

	__forceinline__ __host__ __device__ scalar_for_simd(const value_type &a){
#pragma unroll(EL)
	  for(int i=0; i<EL; i++)
		  d[i] = a;
	}

	__forceinline__ __host__ __device__ scalar_for_simd& operator=(const value_type &a){
#pragma unroll(EL)
	  for(int i=0; i<EL; i++)
		  d[i] = a;
	  return *this;
	}

	__forceinline__ __host__ __device__ scalar_for_simd& operator+=(const scalar_for_simd &a)
	{
#pragma unroll(EL)
		for(int i=0; i<EL; i++)
			d[i] += a.d[i];

		return *this;
	}

	__forceinline__ __host__ __device__ value_type& operator[](const int i){
		return d[i];
	}


};




#endif
