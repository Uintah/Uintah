#!/bin/bash
#SBATCH -t 00:59:00	#expected run time
#SBATCH -N 1 		#number of nodes
#SBATCH -o 1.txt	#output
#SBATCH -e 1.txt	#error
#SBATCH -n 28		#number of mpi tasks
#SBATCH -p soc-gpu-kp  	# Partition on some cluster
#SBATCH -A soc-gpu-kp 	# General CHPC account 
#SBATCH --gres=gpu:p100:1
#SBATCH --mem=32G

# account / partitions names:
# for kingspeak P100: soc-gpu-kp / soc-gpu-kp
# for notchpeak V100: notchpeak-gpu / notchpeak-gpu

export OMP_NUM_THREADS=28
module load gcc
module load cuda


#nvprof --kernels "::TeamTagV2:" --profile-api-trace none --metrics all ../KokkosBatched_Test_Gemm_Cuda.exe -N 16384 -B 15
#nvprof --profile-api-trace none --kernels "::Gemm:" --metrics all ./gpu3 15 16384 2048 32
ulimit -s unlimited

./a.out 512 1 
#./a.out 1024 0
#./a.out 2048 0
#./a.out 4096 0
#./a.out 8192 0
#./a.out 16384 0
#nvprof --query-events

#nvprof  --profile-api-trace none --metrics gld_efficiency,gst_efficiency --events shared_ld_bank_conflict,shared_st_bank_conflict ./a.out 512 1

nvprof  --profile-api-trace none --metrics shared_load_transactions_per_request,shared_load_transactions,gld_efficiency,gst_efficiency,shared_efficiency --events shared_ld_bank_conflict,shared_st_bank_conflict ./a.out 512 0
