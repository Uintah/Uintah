#!/bin/bash

#PBS -V
#PBS -j oe
#PBS -M t.harman@utah.edu
#PBS -m abe
#PBS -q regular
#PBS -A UUSL0001 

export SCI_DEBUG='ComponentTimings:+'

export MPICH_VERSION_DISPLAY=1
export MPICH_ENV_DISPLAY=1

cd $INPUT_DIR

OUT="../$OUTPUT_DIR/$JOB.$nodes.$size.out"
EXE=../../$SUS
MPIRUN="mpiexec_mpt dplace -s 1"

echo "---------------------------------"
date
echo "sus=$SUS"
echo "SCRIPT_DIR=$SCRIPT_DIR"
echo "OUTPUT_DIR=$OUTPUT_DIR"
echo "INPUT_DIR=$INPUT_DIR"
echo "ups=$ups"
echo "procs=$procs"
echo "size=$size"
echo "threads=$threads"
echo "nodes=$nodes"
echo "pwd=`pwd`"
echo "---------------------------------"
    
pwd
export MPICH_MAX_THREAD_SAFETY=multiple
echo "$MPIRUN  $EXE ../inputs/$ups &> $OUT"
$MPIRUN $EXE ../$INPUT_DIR/$ups &> $OUT



