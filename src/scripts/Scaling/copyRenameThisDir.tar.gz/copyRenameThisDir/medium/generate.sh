#!/bin/bash


#-------------------------------------------------------------------

function modify_ups() {
  ups=$1
  num_timesteps=$2
  L0_spacing=$3
  L0_patches=$4
  perl -pi -w -e "s/<<num_timesteps>>/$num_timesteps/" $INPUT_DIR/$ups
  perl -pi -w -e "s/<<L0_spacing>>/$L0_spacing/"       $INPUT_DIR/$ups
  perl -pi -w -e "s/<<L0_patches>>/$L0_patches/"       $INPUT_DIR/$ups
}

#-------------------------------------------------------------------
PROJECT="UUSL0001"
SUS="sus"
OUTPUT_DIR="outputs"
INPUT_DIR="inputs"

#NODES="32 64 128 256 512 1024 2048 4000"
NODES="2048"

#MEMORY=":mem=110GB"      # use 128GB nodes for the low core count runs
MEMORY=""

JOB="medium"
THREADS="1"

#__________________________________
# common to all input files
num_timesteps="100"
L0_spacing="[1.5,1.5,1.5]"


# number of cells == (2259 + 571.5) * 360 * (1759.5 + 559.5)/spacing
#                 = 2,363,014,620/(spacing)^3
# spacing: 0.75 = 5.6012 e9    5.6B cells
# spacing: 1.5 = 700,152,480   700M
# spacing: 3.0 = 87,519,060    87M

cp ../cityScalingInputs/*.xml $INPUT_DIR/


#__________________________________
# 144 cores
ups="4.ups"
L0_patches="[12,2,6]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 288 Cores
ups="8.ups"
L0_patches="[12,4,6]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 576 Corees
ups="16.ups"
L0_patches="[12,4,12]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 1152 Cores
ups="32.ups"
L0_patches="[24,4,12]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 2304 Cores
ups="64.ups"
L0_patches="[24,8,12]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 4608 Cores
ups="128.ups"
L0_patches="[24,8,24]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 9216 Cores
ups="256.ups"
L0_patches="[48,8,24]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 18,432 Cores
ups="512.ups"
L0_patches="[48,16,24]]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 36,864 Cores
ups="1024.ups"
L0_patches="[48,16,48]]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 73,728 Cores
ups="2048.ups"
L0_patches="[96,16,48]]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#__________________________________
# 144000 Cores, 147,456 patches
ups="144000.ups"
L0_patches="[96,32,48]]"
cp ../skel.example.ups $INPUT_DIR/$ups
modify_ups $ups $num_timesteps $L0_spacing $L0_patches

#---------------------------------------------------------

for nodes in $NODES; do
    
    size=`expr $nodes \* 36`
    ups=$nodes.ups
    
    if [ $nodes -lt 128 ]; then
      TIME=04:00:00
    elif [ $nodes -lt 256 ]; then
      TIME=02:00:00
    elif [ $nodes -lt 512 ]; then
      TIME=01:00:00
    else
      TIME=04:00:00
    fi

    if [ $THREADS -eq 1 ]; then
      procs=$size
      threads=1
    else
      procs=$nodes
      threads=$THREADS
    fi 

    export JOB
    export ups
    export size
    export procs
    export threads
    export nodes
    export SUS
    export OUTPUT_DIR
    export INPUT_DIR
    
    echo "qsub -N $JOB.$nodes.$size -l walltime=$TIME -l select=$nodes:ncpus=36:mpiprocs=36$MEMORY ../runsus.sh"
    qsub -N $JOB.$nodes.$size -l walltime=$TIME -l select=$nodes:ncpus=36:mpiprocs=36$MEMORY ../runsus.sh
    
done

