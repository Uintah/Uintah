%______________________________________________________________________
%
% 05/01/07   --Todd
% This matLab script plots scaling spider plot
% You must run src/scripts/extractScalingData prior to running this script.
%
% For high quality images the directory export_fig must be in the same directory as this script.
%______________________________________________________________________


close all;
clear all;
addpath('./export_fig','/usr/bin/')

%________________________________
% USER INPUTS
%'
mult   =8;           % multiplier:  problem size(medium/small)

normFont  = 12;
bigFont   = normFont+2;
smallFont = normFont-2;
                                     % for a listing of available fonts use 'listfonts' in matlab
                                     % use uisetfont for a GUI showing available fonts
fontName  = 'LM Roman 10';
fontWeight = 'bold';                 % normal

%  Relative path for different problem sizes
dirname{1} = sprintf('rmcrt-2l-do-scaling-100-rays-baseline/small/output/scalingData');
dirname{2} = sprintf('rmcrt-2l-do-scaling-100-rays-baseline/medium/output/scalingData');
dirname{3} = sprintf('rmcrt-2l-do-scaling-100-rays-baseline/large/output/scalingData');

legendText = {'Strong' 'Ideal' 'Weak'};

%________________________________
%
set(0,'DefaultFigurePosition',[0,0,1024,768]);
dsort=[];
psizea=[];

for i=1:length(dirname)
   dirname{i}
   d = importdata(dirname{i},' ', 1);
   data = d.data;

  % compute relative problem size
  psize = mult^i./data(:,1);
  if i==1
    psizea=psize;
  end

  % compute (R)un index for these data
  Rindex = ones(length(psize),1).*i;

  % append problem size and Rindex to the sorted data
  dsort=[dsort; Rindex, psize, data ];
end

% dsort matrix layout
%" run #     problem size   MPIProcs    ThreadsPerMPI    totalThreadsCores      startTime    endTime    mean time"
%   1             2            3            4                 5                   6              7           8 

% number of cores and mean time per timestep
cores    = dsort(:,3);
meanTime = dsort(:,8);
  
%__________________________________
% strong scaling
disp('__________________________________ Strong Scaling' )
for i=1:length(dirname)
  dirname{i};
  Rindex = find( dsort(:,1) == i);  % run index

  % show user what is being plotted
  disp(['Run:                   [' num2str(Rindex.') ']'] )
  disp(['Cores:                 [' num2str(cores(Rindex).') ']'])
  disp(['meanTime per timestep: [' num2str(meanTime(Rindex).') ']'])

  % strong scaling curve fit
  ft=fittype(@(b,x)b*x.^-1);
  f = fit( cores(Rindex), meanTime(Rindex),ft)

  % plot #core vs mean time per timestep
  loglog( cores(Rindex), meanTime(Rindex), '-ok','LineWidth',2);
  hold on;

  % plot # core vs curve fit
  loglog(cores(Rindex), f(cores(Rindex)), '-','Color','[0.5,0.5,0.5]', 'LineWidth',1);
  %pause

  hold on;

  % weak scaling placeholder in legend
  loglog(0,0,'--ok','LineWidth',1);
end

%__________________________________
% weak scaling
disp ('')
disp('__________________________________ Weak Scaling' )

for i=1:length(psizea)
  psizea(i);
  Rindex = find(dsort(:,2)>psizea(i)-.0001 & dsort(:,2)>psizea(i)<psizea(i)+.0001);

  % show user what is being plotted
  disp(['Run:                   [' num2str(Rindex.') ']' ] )
  disp(['Cores:                 [' num2str(cores(Rindex).') ']'])
  disp(['meanTime per timestep: [' num2str(meanTime(Rindex).') ']'])

  loglog( cores(Rindex), meanTime(Rindex),'--ok','LineWidth',1);
end

%__________________________________
%  Labels, details and x-axes labels
%
%     MODIFY THIS SECTION

ylabel('Mean Time Per Timestep [s]',        'fontsize', normFont, 'FontName', fontName, 'FontWeight', fontWeight)
xlabel('Cores',                             'fontsize', normFont, 'FontName', fontName, 'FontWeight', fontWeight)
title( {'2-Level Adaptive CPU:RMCRT';'Burns and Christen Benchmark';'OLCF-Titan'} ,'fontsize', bigFont, 'FontName', fontName)

% Details on the run The coordinates x,y are in graph units
str1(1) = {'Unified Scheduler, 16 threads/node'};
str1(2) = {'100 Rays/cell'};
str1(3) = {'Averaged over 7 timesteps'};
text(10,2, str1, 'FontSize', normFont, 'FontName', fontName)

                  % problem sizes  The coordinates x,y are in graph units
text(10,25,  '2.5M Cells',   'FontSize', normFont, 'FontName', fontName, 'BackgroundColor',[1,1,1])
text(64,25, '17.4M Cells',   'FontSize', normFont, 'FontName', fontName, 'BackgroundColor',[1,1,1])
text(1000,25, '136M Cells',  'FontSize', normFont, 'FontName', fontName, 'BackgroundColor',[1,1,1])

set(gca,'FontSize',normFont, 'FontName', fontName, 'FontWeight', fontWeight);
set(gcf, 'Color', 'w')                                  % must set background color to white

legend(legendText,'fontsize',normFont,  'FontName', fontName, 'Location','northeast');

                    %  X and Y axis limits
xlim([ 0 20000 ])
ylim([ 0.0 80]);

                    % Nodes
set(gca,'XTick',[8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384]);
                    % cores
set(gca,'XTickLabel',{ '128', '256', '512', '1', '2K', '4.1K', '8.2K', '16.4K', '32.7K', '65.5K','131K', '262K'});

disp( 'Press return to generate a hardcopy' )
pause;

%__________________________________
% You need the export_fig directory to output high quality images.
% note that png files look fuzzy with export_fig
export_fig spider.pdf -q101 -nocrop
export_fig spider.jpeg -q100

%print('-depsc','spider.eps');
%print('-dpng','spider.png');



