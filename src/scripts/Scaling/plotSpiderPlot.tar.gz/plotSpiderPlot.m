%______________________________________________________________________
%
% 05/01/07   --Todd
% This matLab script plots scaling spider plot
% You must run src/scripts/extractScalingData prior to running this script.
%
% For high quality images the directory export_fig must be in the same directory as this script.
%______________________________________________________________________


close all;
clear all;
addpath('./export_fig','/usr/bin/')


%________________________________
% USER INPUTS
%'
mult          =  8;           % multiplier between problem sizes
nNodes        = [2,4,8,16,32,64,128,256, 512];
nCoresPerNode = 56;
normFontSize  = 12;
bigFontSize   = normFontSize+2;
smallFontSize = normFontSize-2;
                                     % for a listing of available fonts use 'listfonts' in matlab
                                     % use uisetfont for a GUI showing available fonts
fontName   = 'LM Roman 10';
fontWeight = 'bold';                 % normal

% The dirname order is assumed to be (1) small, (2) medium, (3) large
dirname{1} = sprintf('../87MCells/outputs/scalingData');      % small
dirname{2} = sprintf('../700MCells/outputs/scalingData');     % medium
dirname{3} = sprintf('../5.6BCells/outputs/scalingData');     % large

legendText = {'Strong' 'Ideal' 'Weak'};

%________________________________
%
set(0,'DefaultFigurePosition',[0,0,1024,768]);
dsort=[];
relProbSize_1=[];

for i=1:length(dirname)
   d = importdata(dirname{i},' ', 1);
   data = d.data;
  
  % compute relative problem size
  relProbSize = mult^i./data(:,1);
  
  if i==1
    relProbSize_1=relProbSize;
  end
  
  % compute (R)un index for these data
  Rindex = ones( length(relProbSize),1).*i;
  
  % prepend problem size and Rindex to the sorted data
  dsort=[dsort; Rindex, relProbSize, data ];
end

% dsort matrix layout
%" run #     rel problem size MPIProcs    ThreadsPerMPI    totalThreadsCores      startTime    endTime    mean time"
%   1             2            3            4                 5                   6              7           8 

% number of cores and mean time per timestep
cores    = dsort(:,3);
meanTime = dsort(:,8);
  
%__________________________________
% strong scaling
disp('__________________________________ Strong Scaling' )
for i=1:length(dirname)
  Rindex = find( dsort(:,1) == i);  % run index  
 
  % show user what is being plotted
  disp(['scalingStudy:          [' dirname{i} ']'] )
  disp(['Run:                   [' num2str(Rindex.') ']'] )
  disp(['Cores:                 [' num2str(cores(Rindex).') ']']) 
  disp(['meanTime per timestep: [' num2str(meanTime(Rindex).') ']'])

  x=1;
  ft = fittype(@(b,x)b*x.^-1);
  f =  fit(cores(Rindex),meanTime(Rindex),ft);
  
  % plot #core vs mean time per timestep
  loglog( cores(Rindex), meanTime(Rindex), '-ok','LineWidth',2);
  hold on;
  % plot # core vs powerlaw
  loglog(cores(Rindex), f(cores(Rindex)), '-','Color','[0.5,0.5,0.5]', 'LineWidth',1);
  %pause
  
  hold on;
  
  %weak placeholder in legend
  loglog(0,0,'--ok','LineWidth',1);
end

%__________________________________
% weak scaling
disp ('')
disp('__________________________________ Weak Scaling' )
for i=1:length(relProbSize_1)
  relProbSize_1(i);
  targetProbSize = relProbSize_1(i);
  probSizes      = dsort(:,2);
  
  % find the run index with the target problem size
  Rindex = find( (targetProbSize-0.0001 <= probSizes)  & (probSizes <=  targetProbSize + 0.0001 ));
  
  % show user what is being plotted
  disp(['Run:                   [' num2str(Rindex.') ']' ] )
  disp(['targetProbSize:        [' num2str(targetProbSize) ']' ] )
  disp(['Cores:                 [' num2str(cores(Rindex).') ']']) 
  disp(['meanTime per timestep: [' num2str(meanTime(Rindex).') ']'])
  
  loglog( cores(Rindex), meanTime(Rindex),'--ok','LineWidth',1);
end

%__________________________________
% set plot variables

ylabel('Mean Time Per Timestep [s]',        'fontsize', normFontSize, 'FontName', fontName, 'FontWeight', fontWeight)
xlabel('Cores',                             'fontsize', normFontSize, 'FontName', fontName, 'FontWeight', fontWeight)
title('Uintah:MPMICE, TACC-Frontera System','fontsize', bigFontSize, 'FontName', fontName)

str1(1) = {'Scheduler: MPI'};
str1(2) = {'1 patch per core'};
str1(3) = {'Averaged over 80 timesteps'};
text(170,0.5,str1, 'FontSize', normFontSize, 'FontName', fontName)

% problem sizes  The coordinates x,y are in graph units
text('Units', 'normalized', 'Position', [0.01,0.93], 'String', {'87M Cells', '193K particles'},   'FontSize', smallFontSize, 'FontName', fontName, 'BackgroundColor',[1,1,1] )
text('Units', 'normalized', 'Position', [0.35,0.93], 'String', {'700M Cells', '1.35M particles'}, 'FontSize', smallFontSize, 'FontName', fontName, 'BackgroundColor',[1,1,1] )
text('Units', 'normalized', 'Position', [0.65,0.93], 'String', {'5.6B Cells', '10.83M particles'},'FontSize', smallFontSize, 'FontName', fontName, 'BackgroundColor',[1,1,1] )

set(gca,'FontSize',normFontSize, 'FontName', fontName, 'FontWeight', fontWeight);
set(gcf, 'Color', 'w')                                  % must set background color to white

legend(legendText,'fontsize',normFontSize,  'FontName', fontName, 'Location','northeast');

xTicks    = nNodes.*nCoresPerNode;
xTickStr  = string( int2str(xTicks) );
xTickStr  = split( xTickStr );

xlim([ min(xTicks) max(xTicks) ]);
ylim([ 0.0 30]);

set(gca,'XTick',     xTicks);
set(gca,'XTickLabel',xTickStr);
ax = gca;
ax.XTickLabelRotation = 45;


disp( 'Press return to generate a hardcopy' )
pause;


% You need the export_fig directory to output high quality images.
% note that png files look fuzzy with export_fig
export_fig spider.pdf -q101 -nocrop
export_fig spider.jpeg -q100

%print('-depsc','spider.eps');
%print('-dpng','spider.png');

