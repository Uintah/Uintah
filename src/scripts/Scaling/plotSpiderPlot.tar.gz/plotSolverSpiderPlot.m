%_________________________________
% 02/11/19   --Todd
% This matLab script generates the spider plot that 
% also shows the average time spent in hypre.
% You must run src/scripts/extractScalingData first

close all;
clear all;
addpath('./export_fig','/usr/bin/')

%________________________________
% USER INPUTS
%
mult   =8;           % multiplier

normFont  = 12;
bigFont   = normFont+2;
smallFont = normFont-2;
                                     % for a listing of available fonts use 'listfonts' in matlab
                                     % use uisetfont for a GUI showing available fonts
fontName  = 'LM Roman 10';
fontWeight = 'bold';    % normal

dirname{1} = sprintf('../87MCells/outputs/solverScalingData');
dirname{2} = sprintf('../700M/outputs/solverScalingData');
dirname{3} = sprintf('../5.6BCells/outputs/solverScalingData');

legendText = {'Strong' 'Hypre' 'Ideal'};

%________________________________
%

dsort=[];
psizea=[];

for i=1:length(dirname)
   dirname{i}
   d = importdata(dirname{i},' ', 1);
   data = d.data;
  
  %compute relative problem size
  psize = mult^i./data(:,1);
  if i==1
    psizea=psize;
  end
  
  %compute (R)un index for these data
  Rindex = ones(length(psize),1).*i;
  
  %append problem size and Rindex to the sorted data
  dsort=[dsort; Rindex, psize, data ];
end

%__________________________________
% dsort matrix layout  NOT the file size
%" run #     problem size     MPIprocs  threadsPerMPI  totalThreads  startWallTime  endWallTime  totalSolve+SetupTime  totalSolveTime  AveTimePerTimeStep  aveTotalSolve+setup  aveSolveTime
%   1             2              3            4            5              6             7              8                     9               10                   11                12 
%__________________________________


% number of cores, mean time per timestep, mean solve time per timestep
cores         = dsort(:,3);
meanTime      = dsort(:,10);
meanSolveTime = dsort(:,11);
  

%__________________________________
% strong scaling
set(0,'DefaultFigurePosition',[0,0,1024,768]);

disp('__________________________________ Strong Scaling' )

for i=1:length(dirname)
  dirname{i};
  Rindex = find( dsort(:,1) == i);  % run index  
 
  % show user what is being plotted
  disp(['Run:                   [' num2str(Rindex.') ']'] )
  disp(['Cores:                       [' num2str(cores(Rindex).') ']']) 
  disp(['meanTime per timestep:       [' num2str(meanTime(Rindex).') ']'])
  disp(['mean solveTime per timestep: [' num2str(meanSolveTime(Rindex).') ']'])
  

  ft= fittype(@(b,x)b*x.^-1);
  f = fit(cores(Rindex),meanTime(Rindex),ft);
  
  % plot #core vs mean time per timestep
  loglog( cores(Rindex), meanTime(Rindex), '-ok','LineWidth',2);
  hold on;
  
  % plot #cores vs meanSolver time per timestep
  loglog( cores(Rindex), meanSolveTime(Rindex), '-+k','Color','[0.0,1.0,0.0]', 'LineWidth',1);
  hold on;
  
  % plot # core vs powerlaw
  loglog(cores(Rindex), f(cores(Rindex)), '-','Color','[0.5,0.5,0.5]', 'LineWidth',1);  
  %hold on;

end

%__________________________________
% set plot variables

ylabel('Mean Time Per Timestep [s]',        'fontsize', normFont, 'FontName', fontName, 'FontWeight', fontWeight)
xlabel('Cores',                             'fontsize', normFont, 'FontName', fontName, 'FontWeight', fontWeight)
title('Uintah:MPMICE, NCAR-Cheyenne System','fontsize', bigFont, 'FontName', fontName)

str1(1) = {'Scheduler: MPI'};
str1(2) = {'1 patch per core'};
str1(3) = {'Averaged over 97 timesteps'};
text(170,0.5,str1, 'FontSize', normFont, 'FontName', fontName)


% problem sizes  The coordinates x,y are in graph units
text(50,25,  '87M Cells, 193K particles',   'FontSize', normFont, 'FontName', fontName, 'BackgroundColor',[1,1,1])
text(288,30, '700M Cells, 1.35M particles', 'FontSize', normFont, 'FontName', fontName, 'BackgroundColor',[1,1,1])
text(2300,27, '5.6B Cells, 10.83M particles','FontSize', normFont, 'FontName', fontName, 'BackgroundColor',[1,1,1])

set(gca,'FontSize',normFont, 'FontName', fontName, 'FontWeight', fontWeight);
set(gcf, 'Color', 'w')                                  % must set background color to white

legend(legendText,'fontsize',normFont,  'FontName', fontName, 'Location','northeast');

xlim([ 72 73728 ]);
ylim([ 0.0 50]);

set(gca,'XTick',[36, 72, 144, 288, 576, 1152, 2304, 4608, 9216, 18432, 36864, 73728]);
set(gca,'XTickLabel',{ '36', '72', '144', '288', '576', '1152', '2.3K', '4.6K', '9.2K', '18.4K','36.8K', '73.7K'});

disp( 'Press return to generate a hardcopy' )
pause;


% You need the export_fig directory to output high quality images.
% note that png files look fuzzy with export_fig
export_fig solverSpider.pdf -q101 -nocrop
export_fig solverSpider.jpeg -q100

%print('-depsc','spider.eps');
%print('-dpng','spider.png');



