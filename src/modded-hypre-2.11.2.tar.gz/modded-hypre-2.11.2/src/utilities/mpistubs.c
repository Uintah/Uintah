/*BHEADER**********************************************************************
 * Copyright (c) 2008,  Lawrence Livermore National Security, LLC.
 * Produced at the Lawrence Livermore National Laboratory.
 * This file is part of HYPRE.  See file COPYRIGHT for details.
 *
 * HYPRE is free software; you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License (as published by the Free
 * Software Foundation) version 2.1 dated February 1999.
 *
 * $Revision$
 ***********************************************************************EHEADER*/

#include "_hypre_utilities.h"

#include<stdatomic.h>
#include<math.h>
//#include <threads.h>

extern struct MPIR_Request * recvq_unexpected_head;

/******************************************************************************
 * This routine is the same in both the sequential and normal cases
 *
 * The 'comm' argument for MPI_Comm_f2c is MPI_Fint, which is always the size of
 * a Fortran integer and hence usually the size of hypre_int.
 *****************************************************************************/

//#define print_mpi_calls 1
#define TREAT_THREAD_AS_RANK 1
MPI_Comm comm = MPI_COMM_WORLD;
__thread int g_rank=0;
__thread int g_thread_id=0;

const char* getOpName(int op)
{
	switch(op)
	{
	case 	 MPI_MAX	 : return(" MPI_MAX");
	case 	 MPI_MIN	 : return(" MPI_MIN");
	case 	 MPI_SUM	 : return(" MPI_SUM");
	case 	 MPI_PROD	 : return(" MPI_PROD");
	case 	 MPI_LAND	 : return(" MPI_LAND");
	case 	 MPI_BAND	 : return(" MPI_BAND");
	case 	 MPI_LOR	 : return(" MPI_LOR");
	case 	 MPI_BOR	 : return(" MPI_BOR");
	case 	 MPI_LXOR	 : return(" MPI_LXOR");
	case 	 MPI_BXOR	 : return(" MPI_BXOR");
	case 	 MPI_MINLOC	 : return(" MPI_MINLOC");
	case 	 MPI_MAXLOC	 : return(" MPI_MAXLOC");
	case 	 MPI_REPLACE : return(" MPI_REPLACE");
	//case 	 MPI_NO_OP	 : return(" MPI_NO_OP");
	case 	 MPI_CHAR: return(" MPI_CHAR");
	case MPI_WCHAR: return(" MPI_WCHAR");
	case MPI_SHORT: return(" MPI_SHORT");
	case MPI_INT: return(" MPI_INT");
	case MPI_LONG: return(" MPI_LONG");
	case MPI_LONG_LONG	: return(" MPI_LONG_LONG	");
	case MPI_SIGNED_CHAR: return(" MPI_SIGNED_CHAR");
	case MPI_UNSIGNED_CHAR: return(" MPI_UNSIGNED_CHAR");
	case MPI_UNSIGNED_SHORT: return(" MPI_UNSIGNED_SHORT");
	case MPI_UNSIGNED_LONG: return(" MPI_UNSIGNED_LONG");
	case MPI_UNSIGNED: return(" MPI_UNSIGNED");
	case MPI_FLOAT: return(" MPI_FLOAT");
	case MPI_DOUBLE: return(" MPI_DOUBLE");
	case MPI_LONG_DOUBLE: return(" MPI_LONG_DOUBLE");
	case MPI_C_FLOAT_COMPLEX: return(" MPI_C_FLOAT_COMPLEX");
	case MPI_C_DOUBLE_COMPLEX: return(" MPI_C_DOUBLE_COMPLEX");
	case MPI_C_BOOL: return(" MPI_C_BOOL");
	case MPI_LOGICAL: return(" MPI_LOGICAL");
	case MPI_C_LONG_DOUBLE_COMPLEX: return(" MPI_C_LONG_DOUBLE_COMPLEX");
	case MPI_INT8_T: return(" MPI_INT8_T");
	case MPI_INT16_T: return(" MPI_INT16_T");
	case MPI_INT32_T: return(" MPI_INT32_T");
	case MPI_INT64_T	: return(" MPI_INT64_T	");
	case MPI_UINT8_T: return(" MPI_UINT8_T");
	case MPI_UINT16_T: return(" MPI_UINT16_T");
	case MPI_UINT32_T: return(" MPI_UINT32_T");
	case MPI_UINT64_T: return(" MPI_UINT64_T");
	case MPI_BYTE: return(" MPI_BYTE");
	case MPI_PACKED: return(" MPI_PACKED");

	default				 : return(" wrong op");
	}
}
volatile int g_num_of_threads = 0;	//total number of threads.
int (*hypre_get_thread_id)();		//function pointer to store function which will return thread id. C does not allow thread local storage. Hence pass a function
							//to return thread id - could be custom written function or could be library call such as omp_get_thread_num
							//WHOLE IMPLEMENTATION WILL FAIL IF THIS FUNCTION FAILS

#ifdef TREAT_THREAD_AS_RANK

volatile void * volatile g_collective_sync_buff=NULL;
atomic_int g_collective_sync_count;
atomic_int g_collective_sync_copy_count;
atomic_int g_barrier;
atomic_int g_barrier1;
//tag multipliers. assuming default values of 8,8,16 -> from LSB to MSB, 16 bits for tag, 8 bits for dest thread id, 8 bits for src thread id
int dest_multiplier = 0x00010000, src_multiplier=0x01000000, src_eliminate_and=0x00ffffff;
//int new_tag = tag == MPI_ANY_TAG ? MPI_ANY_TAG : (src_thread * 0x01000000) + (dest_thread * 0x00010000) + tag % 0x00010000; coverted to
//int new_tag = tag == MPI_ANY_TAG ? MPI_ANY_TAG : (src_thread * src_multiplier) + (dest_thread * dest_multiplier) + tag % dest_multiplier;

void hypre_set_num_threads(int n, int (*f)())
{
	g_num_of_threads = n;
	hypre_get_thread_id=f;
	atomic_store_explicit (&g_collective_sync_count, 0, memory_order_seq_cst);
	atomic_store_explicit (&g_collective_sync_copy_count, 0, memory_order_seq_cst);
	atomic_store_explicit (&g_barrier, 0, memory_order_seq_cst);
	atomic_store_explicit (&g_barrier1, 0, memory_order_seq_cst);

	//HYPRE_TAG format: <bits for threads>,<bits for tag>. same number of bits will be used for src and dest thread ids.
	//e.g. to get same as default values, export HYPRE_TAG=8,16. This will assign left most 8 bits for src, 8 bits for dest and last 16 bits for tag
	const char* hypre_tag_str = getenv("HYPRE_TAG"); //use diff env variable if it conflicts with OMP. but using same will be consistent.
	char tag_str[16];

	if(hypre_tag_str)
	{
			strcpy(tag_str, hypre_tag_str);
			const char s[2] = ",";
			char *token;
			token = strtok(tag_str, s);	/* get the first token */
			int dest_bits = atoi(token);
			token = strtok(NULL, s);
			int tag_bits =  atoi(token);

			dest_multiplier = pow(2, tag_bits);
			src_multiplier = pow(2, (tag_bits + dest_bits));
			src_eliminate_and = src_multiplier - 1;

			//printf("dest_multiplier: %08x, src_multiplier: %08x, src_eliminate_and: %08x\n", dest_multiplier, src_multiplier, src_eliminate_and);
	}
}

void hypre_init_thread()
{
	MPI_Comm_rank(comm, &g_rank);
	g_thread_id = hypre_get_thread_id();
	g_rank = g_rank * g_num_of_threads + g_thread_id;
	//printf("rank: %d, thread: %d\n", g_rank, g_thread_id);

}


void hypre_copy_data_for_sync_collectives(void *sendbuf, void *recvbuf, HYPRE_Int count, hypre_MPI_Datatype datatype)
{
	int thread_id = g_thread_id;
	int i,j;
	unsigned char *crecvbuf = (unsigned char *)recvbuf;	//cast into bytes
	unsigned char *csendbuf = (unsigned char *)sendbuf;
	int mpi_datatype_size;
	MPI_Type_size(datatype, &mpi_datatype_size);

/*	atomic_fetch_add_explicit(&g_barrier, 1, memory_order_seq_cst);
	while(atomic_load_explicit(&g_barrier, memory_order_seq_cst)%g_num_of_threads != 0);	//wait till all threads reach here.

	if(thread_id==0)	//this approach never frees  memory chunk. so there will be leak. but seems faster than
	{
		if(g_collective_sync_buff)
			free(g_collective_sync_buff);
		g_collective_sync_buff = NULL;
		atomic_store_explicit (&g_collective_sync_count, 0, memory_order_seq_cst);
		atomic_store_explicit (&g_collective_sync_copy_count, 0, memory_order_seq_cst);
		//atomic_store_explicit (&g_barrier, 0, memory_order_seq_cst);
	}

	atomic_fetch_add_explicit(&g_barrier1, 1, memory_order_seq_cst);
	while(atomic_load_explicit(&g_barrier1, memory_order_seq_cst)%g_num_of_threads != 0);	//wait till all threads reach here.
*/
	if(thread_id==0)	//if thread id is 0, allocate buffer. other wait till buffer is allocated.
	{
		g_collective_sync_buff = (volatile void volatile*) ((volatile unsigned char volatile* )malloc(g_num_of_threads*mpi_datatype_size*count));
	}
	else
	{
		//printf("%d - %d waiting for thread 0 to allocate\n", me, thread_id);
		while(!g_collective_sync_buff);//{printf("%d wait %s %d\n",thread_id,  __FILE__, __LINE__);}	//other threads wait till buffer is allocated
		//printf("%d - %d waiting for thread 0 to allocate finished\n", me, thread_id);
	}

	for(i=0; i < count; i++)
		for(j = 0; j<mpi_datatype_size; j++)
		{
			((volatile  unsigned volatile char*)g_collective_sync_buff)[mpi_datatype_size*(i*g_num_of_threads + thread_id) + j] = csendbuf[i*mpi_datatype_size+j];	//each thread copies data at UNIQUE location. no data races. Group together numbers corresponding to 1 reduction operation
			//printf("location : %d %d %d\n", thread_id, mpi_datatype_size*(i*g_num_of_threads + thread_id) + j, i*mpi_datatype_size+j);
		}
	atomic_fetch_add_explicit(&g_collective_sync_count, 1, memory_order_seq_cst);	//increment thread counter.

	//wait till all threads get here
	//printf("%d - %d waiting for other threads in hypre_copy_data_for_sync_collectives\n", me, thread_id);
	while(atomic_load_explicit(&g_collective_sync_count, memory_order_seq_cst) < g_num_of_threads);//{printf("%d wait %s %d\n",thread_id, __FILE__, __LINE__);}
	//printf("%d - %d waiting for other threads in hypre_copy_data_for_sync_collectives finished\n", me, thread_id);

}



# define loop_over_reductions(count, op,recv, recv_init)	\
	int i,j;							\
	for(i=0; i < count ;i++)			\
	{									\
		recv[i] = recv_init;			\
		int s = i*g_num_of_threads;		\
		int e = i*g_num_of_threads+g_num_of_threads;	\
		for(j = s; j<e; j++)			\
			op;							\
	}

//macro builds expressions for reductions and calls loop_over_reductions to reduce values in local buffers.
#define local_threaded_reduce(send, recv,  count, op, r)	\
{									\
	if(op==MPI_SUM)		{loop_over_reductions(count, recv[i] += send[j], recv, 0);	}	\
	else if(op==MPI_MAX)		{loop_over_reductions(count, recv[i] = (recv[i] > send[j] ? recv[i] : send[j]), recv, 0);}		\
	else if(op==MPI_MIN)		{loop_over_reductions(count, recv[i] = (recv[i] < send[j] ? recv[i] : send[j]), recv, 0);}		\
	else if(op==MPI_PROD)		{loop_over_reductions(count, recv[i] *= send[j], recv, 1);}		\
	else printf("error. Operation %s is not added in hypre mpistubs.c\n", getOpName(op));	\
}

#define local_threaded_reduce_for_INT(send, recv,  count, op, r)	\
{									\
	if(op==MPI_SUM)		{loop_over_reductions(count, recv[i] += send[j], recv, 0);	}	\
	else if(op==MPI_MAX)		{loop_over_reductions(count, recv[i] = (recv[i] > send[j] ? recv[i] : send[j]), recv, -9999999999);}		\
	else if(op==MPI_MIN)		{loop_over_reductions(count, recv[i] = (recv[i] < send[j] ? recv[i] : send[j]), recv, 9999999999);}		\
	else if(op==MPI_PROD)		{loop_over_reductions(count, recv[i] *= send[j], recv, 1);}		\
  	else if(op==MPI_LAND)		{loop_over_reductions(count, recv[i] = recv[i] && send[j], recv, 1);}		\
	else if(op==MPI_BAND)		{loop_over_reductions(count, recv[i] = recv[i] &  send[j], recv, 0xffffffffffffffff);}		\
	else if(op==MPI_LOR)		{loop_over_reductions(count, recv[i] = recv[i] || send[j], recv, 0);}		\
	else if(op==MPI_BOR)		{loop_over_reductions(count, recv[i] = recv[i] |  send[j], recv, 0);}		\
	else printf("error. Operation %s is not added in hypre mpistubs.c\n", getOpName(op));	\
}


#endif

// end MODS

hypre_MPI_Comm
hypre_MPI_Comm_f2c( hypre_int comm )
{
#ifdef HYPRE_HAVE_MPI_COMM_F2C
   return (hypre_MPI_Comm) MPI_Comm_f2c(comm);
#else
   return (hypre_MPI_Comm) comm;
#endif
}

/******************************************************************************
 * MPI stubs to generate serial codes without mpi
 *****************************************************************************/

#ifdef HYPRE_SEQUENTIAL

HYPRE_Int
hypre_MPI_Init( hypre_int   *argc,
                char      ***argv )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Finalize( )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Abort( hypre_MPI_Comm comm,
                 HYPRE_Int      errorcode )
{
   return(0);
}

HYPRE_Real
hypre_MPI_Wtime( )
{
   return(0.0);
}

HYPRE_Real
hypre_MPI_Wtick( )
{
   return(0.0);
}

HYPRE_Int
hypre_MPI_Barrier( hypre_MPI_Comm comm )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Comm_create( hypre_MPI_Comm   comm,
                       hypre_MPI_Group  group,
                       hypre_MPI_Comm  *newcomm )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Comm_dup( hypre_MPI_Comm  comm,
                    hypre_MPI_Comm *newcomm )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Comm_size( hypre_MPI_Comm  comm,
                     HYPRE_Int      *size )
{ 
   *size = 1;
   return(0);
}

HYPRE_Int
hypre_MPI_Comm_rank( hypre_MPI_Comm  comm,
                     HYPRE_Int      *rank )
{ 
   *rank = 0;
   return(0);
}

HYPRE_Int
hypre_MPI_Comm_free( hypre_MPI_Comm *comm )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Comm_group( hypre_MPI_Comm   comm,
                      hypre_MPI_Group *group )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Comm_split( hypre_MPI_Comm  comm,
                      HYPRE_Int       n,
                      HYPRE_Int       m,
                      hypre_MPI_Comm *comms )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Group_incl( hypre_MPI_Group  group,
                      HYPRE_Int        n,
                      HYPRE_Int       *ranks,
                      hypre_MPI_Group *newgroup )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Group_free( hypre_MPI_Group *group )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Address( void           *location,
                   hypre_MPI_Aint *address )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Get_count( hypre_MPI_Status   *status,
                     hypre_MPI_Datatype  datatype,
                     HYPRE_Int          *count )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Alltoall( void               *sendbuf,
                    HYPRE_Int           sendcount,
                    hypre_MPI_Datatype  sendtype,
                    void               *recvbuf,
                    HYPRE_Int           recvcount,
                    hypre_MPI_Datatype  recvtype,
                    hypre_MPI_Comm      comm )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Allgather( void               *sendbuf,
                     HYPRE_Int           sendcount,
                     hypre_MPI_Datatype  sendtype,
                     void               *recvbuf,
                     HYPRE_Int           recvcount,
                     hypre_MPI_Datatype  recvtype,
                     hypre_MPI_Comm      comm ) 
{
   HYPRE_Int i;

   switch (sendtype)
   {
      case hypre_MPI_INT:
      {
         HYPRE_Int *crecvbuf = (HYPRE_Int *)recvbuf;
         HYPRE_Int *csendbuf = (HYPRE_Int *)sendbuf;
         for (i = 0; i < sendcount; i++)
         {
	    crecvbuf[i] = csendbuf[i];
         }
      } 
      break;

      case hypre_MPI_DOUBLE:
      {
         double *crecvbuf = (double *)recvbuf;
         double *csendbuf = (double *)sendbuf;
         for (i = 0; i < sendcount; i++)
         {
	    crecvbuf[i] = csendbuf[i];
         }
      } 
      break;

      case hypre_MPI_CHAR:
      {
         char *crecvbuf = (char *)recvbuf;
         char *csendbuf = (char *)sendbuf;
         for (i = 0; i < sendcount; i++)
         {
	    crecvbuf[i] = csendbuf[i];
         }
      } 
      break;

      case hypre_MPI_BYTE:
      {
         memcpy(recvbuf, sendbuf, sendcount);
      } 
      break;

      case hypre_MPI_REAL:
      {
         HYPRE_Real *crecvbuf = (HYPRE_Real *)recvbuf;
         HYPRE_Real *csendbuf = (HYPRE_Real *)sendbuf;
         for (i = 0; i < sendcount; i++)
         {
	    crecvbuf[i] = csendbuf[i];
         }
      } 
      break;

      case hypre_MPI_COMPLEX:
      {
         HYPRE_Complex *crecvbuf = (HYPRE_Complex *)recvbuf;
         HYPRE_Complex *csendbuf = (HYPRE_Complex *)sendbuf;
         for (i = 0; i < sendcount; i++)
         {
	    crecvbuf[i] = csendbuf[i];
         }
      } 
      break;
   }

   return(0);
}

HYPRE_Int
hypre_MPI_Allgatherv( void               *sendbuf,
                      HYPRE_Int           sendcount,
                      hypre_MPI_Datatype  sendtype,
                      void               *recvbuf,
                      HYPRE_Int          *recvcounts,
                      HYPRE_Int          *displs, 
                      hypre_MPI_Datatype  recvtype,
                      hypre_MPI_Comm      comm ) 
{ 
   return ( hypre_MPI_Allgather(sendbuf, sendcount, sendtype,
                                recvbuf, *recvcounts, recvtype, comm) );
}

HYPRE_Int
hypre_MPI_Gather( void               *sendbuf,
                  HYPRE_Int           sendcount,
                  hypre_MPI_Datatype  sendtype,
                  void               *recvbuf,
                  HYPRE_Int           recvcount,
                  hypre_MPI_Datatype  recvtype,
                  HYPRE_Int           root,
                  hypre_MPI_Comm      comm )
{
   return ( hypre_MPI_Allgather(sendbuf, sendcount, sendtype,
                                recvbuf, recvcount, recvtype, comm) );
}

HYPRE_Int
hypre_MPI_Gatherv( void              *sendbuf,
                  HYPRE_Int           sendcount,
                  hypre_MPI_Datatype  sendtype,
                  void               *recvbuf,
                  HYPRE_Int          *recvcounts,
                  HYPRE_Int          *displs,
                  hypre_MPI_Datatype  recvtype,
                  HYPRE_Int           root,
                  hypre_MPI_Comm      comm )
{
   return ( hypre_MPI_Allgather(sendbuf, sendcount, sendtype,
                                recvbuf, *recvcounts, recvtype, comm) );
}

HYPRE_Int
hypre_MPI_Scatter( void               *sendbuf,
                   HYPRE_Int           sendcount,
                   hypre_MPI_Datatype  sendtype,
                   void               *recvbuf,
                   HYPRE_Int           recvcount,
                   hypre_MPI_Datatype  recvtype,
                   HYPRE_Int           root,
                   hypre_MPI_Comm      comm )
{
   return ( hypre_MPI_Allgather(sendbuf, sendcount, sendtype,
                                recvbuf, recvcount, recvtype, comm) );
}

HYPRE_Int
hypre_MPI_Scatterv( void               *sendbuf,
                   HYPRE_Int           *sendcounts,
                   HYPRE_Int           *displs,
                   hypre_MPI_Datatype   sendtype,
                   void                *recvbuf,
                   HYPRE_Int            recvcount,
                   hypre_MPI_Datatype   recvtype,
                   HYPRE_Int            root,
                   hypre_MPI_Comm       comm )
{
   return ( hypre_MPI_Allgather(sendbuf, *sendcounts, sendtype,
                                recvbuf, recvcount, recvtype, comm) );
}

HYPRE_Int
hypre_MPI_Bcast( void               *buffer,
                 HYPRE_Int           count,
                 hypre_MPI_Datatype  datatype,
                 HYPRE_Int           root,
                 hypre_MPI_Comm      comm ) 
{ 
   return(0);
}

HYPRE_Int
hypre_MPI_Send( void               *buf,
                HYPRE_Int           count,
                hypre_MPI_Datatype  datatype,
                HYPRE_Int           dest,
                HYPRE_Int           tag,
                hypre_MPI_Comm      comm ) 
{ 
   return(0);
}

HYPRE_Int
hypre_MPI_Recv( void               *buf,
                HYPRE_Int           count,
                hypre_MPI_Datatype  datatype,
                HYPRE_Int           source,
                HYPRE_Int           tag,
                hypre_MPI_Comm      comm,
                hypre_MPI_Status   *status )
{ 
   return(0);
}

HYPRE_Int
hypre_MPI_Isend( void               *buf,
                 HYPRE_Int           count,
                 hypre_MPI_Datatype  datatype,
                 HYPRE_Int           dest,
                 HYPRE_Int           tag,
                 hypre_MPI_Comm      comm,
                 hypre_MPI_Request  *request )
{ 
   return(0);
}

HYPRE_Int
hypre_MPI_Irecv( void               *buf,
                 HYPRE_Int           count,
                 hypre_MPI_Datatype  datatype,
                 HYPRE_Int           source,
                 HYPRE_Int           tag,
                 hypre_MPI_Comm      comm,
                 hypre_MPI_Request  *request )
{ 
   return(0);
}

HYPRE_Int
hypre_MPI_Send_init( void               *buf,
                     HYPRE_Int           count,
                     hypre_MPI_Datatype  datatype,
                     HYPRE_Int           dest,
                     HYPRE_Int           tag, 
                     hypre_MPI_Comm      comm,
                     hypre_MPI_Request  *request )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Recv_init( void               *buf,
                     HYPRE_Int           count,
                     hypre_MPI_Datatype  datatype,
                     HYPRE_Int           dest,
                     HYPRE_Int           tag, 
                     hypre_MPI_Comm      comm,
                     hypre_MPI_Request  *request )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Irsend( void               *buf,
                  HYPRE_Int           count,
                  hypre_MPI_Datatype  datatype,
                  HYPRE_Int           dest,
                  HYPRE_Int           tag, 
                  hypre_MPI_Comm      comm,
                  hypre_MPI_Request  *request )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Startall( HYPRE_Int          count,
                    hypre_MPI_Request *array_of_requests )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Probe( HYPRE_Int         source,
                 HYPRE_Int         tag,
                 hypre_MPI_Comm    comm,
                 hypre_MPI_Status *status )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Iprobe( HYPRE_Int         source,
                  HYPRE_Int         tag,
                  hypre_MPI_Comm    comm,
                  HYPRE_Int        *flag,
                  hypre_MPI_Status *status )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Test( hypre_MPI_Request *request,
                HYPRE_Int         *flag,
                hypre_MPI_Status  *status )
{
   *flag = 1;
   return(0);
}

HYPRE_Int
hypre_MPI_Testall( HYPRE_Int          count,
                   hypre_MPI_Request *array_of_requests,
                   HYPRE_Int         *flag,
                   hypre_MPI_Status  *array_of_statuses )
{
   *flag = 1;
   return(0);
}

HYPRE_Int
hypre_MPI_Wait( hypre_MPI_Request *request,
                hypre_MPI_Status  *status )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Waitall( HYPRE_Int          count,
                   hypre_MPI_Request *array_of_requests,
                   hypre_MPI_Status  *array_of_statuses )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Waitany( HYPRE_Int          count,
                   hypre_MPI_Request *array_of_requests,
                   HYPRE_Int         *index,
                   hypre_MPI_Status  *status )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Allreduce( void              *sendbuf,
                     void              *recvbuf,
                     HYPRE_Int          count,
                     hypre_MPI_Datatype datatype,
                     hypre_MPI_Op       op,
                     hypre_MPI_Comm     comm )
{ 
   HYPRE_Int i;
   
   switch (datatype)
   {
      case hypre_MPI_INT:
      {
         HYPRE_Int *crecvbuf = (HYPRE_Int *)recvbuf;
         HYPRE_Int *csendbuf = (HYPRE_Int *)sendbuf;
         for (i = 0; i < count; i++)
         {
            crecvbuf[i] = csendbuf[i];
         }
         
      } 
      break;

      case hypre_MPI_DOUBLE:
      {
         double *crecvbuf = (double *)recvbuf;
         double *csendbuf = (double *)sendbuf;
         for (i = 0; i < count; i++)
         {
            crecvbuf[i] = csendbuf[i];
         }
      } 
      break;

      case hypre_MPI_CHAR:
      {
         char *crecvbuf = (char *)recvbuf;
         char *csendbuf = (char *)sendbuf;
         for (i = 0; i < count; i++)
         {
            crecvbuf[i] = csendbuf[i];
         }
      } 
      break;

      case hypre_MPI_BYTE:
      {
         memcpy(recvbuf, sendbuf, count);
      } 
      break;

      case hypre_MPI_REAL:
      {
         HYPRE_Real *crecvbuf = (HYPRE_Real *)recvbuf;
         HYPRE_Real *csendbuf = (HYPRE_Real *)sendbuf;
         for (i = 0; i < count; i++)
         {
            crecvbuf[i] = csendbuf[i];
         }
      } 
      break;

      case hypre_MPI_COMPLEX:
      {
         HYPRE_Complex *crecvbuf = (HYPRE_Complex *)recvbuf;
         HYPRE_Complex *csendbuf = (HYPRE_Complex *)sendbuf;
         for (i = 0; i < count; i++)
         {
            crecvbuf[i] = csendbuf[i];
         }
      } 
      break;
   }

   return 0;
}

HYPRE_Int
hypre_MPI_Reduce( void               *sendbuf,
                  void               *recvbuf,
                  HYPRE_Int           count,
                  hypre_MPI_Datatype  datatype,
                  hypre_MPI_Op        op,
                  HYPRE_Int           root,
                  hypre_MPI_Comm      comm )
{ 
   hypre_MPI_Allreduce(sendbuf, recvbuf, count, datatype, op, comm);
   return 0;
}

HYPRE_Int
hypre_MPI_Scan( void               *sendbuf,
                void               *recvbuf,
                HYPRE_Int           count,
                hypre_MPI_Datatype  datatype,
                hypre_MPI_Op        op,
                hypre_MPI_Comm      comm )
{ 
   hypre_MPI_Allreduce(sendbuf, recvbuf, count, datatype, op, comm);
   return 0;
}

HYPRE_Int
hypre_MPI_Request_free( hypre_MPI_Request *request )
{
   return 0;
}

HYPRE_Int
hypre_MPI_Type_contiguous( HYPRE_Int           count,
                           hypre_MPI_Datatype  oldtype,
                           hypre_MPI_Datatype *newtype )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Type_vector( HYPRE_Int           count,
                       HYPRE_Int           blocklength,
                       HYPRE_Int           stride,
                       hypre_MPI_Datatype  oldtype,
                       hypre_MPI_Datatype *newtype )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Type_hvector( HYPRE_Int           count,
                        HYPRE_Int           blocklength,
                        hypre_MPI_Aint      stride,
                        hypre_MPI_Datatype  oldtype,
                        hypre_MPI_Datatype *newtype )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Type_struct( HYPRE_Int           count,
                       HYPRE_Int          *array_of_blocklengths,
                       hypre_MPI_Aint     *array_of_displacements,
                       hypre_MPI_Datatype *array_of_types,
                       hypre_MPI_Datatype *newtype )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Type_commit( hypre_MPI_Datatype *datatype )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Type_free( hypre_MPI_Datatype *datatype )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Op_create( hypre_MPI_User_function *function, hypre_int commute, hypre_MPI_Op *op )
{
   return(0);
}

HYPRE_Int
hypre_MPI_Op_free( hypre_MPI_Op *op )
{
   return(0);
}
/******************************************************************************
 * MPI stubs to do casting of HYPRE_Int and hypre_int correctly
 *****************************************************************************/

#else

HYPRE_Int
hypre_MPI_Init( hypre_int   *argc,
                char      ***argv )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Init(argc, argv);
}

HYPRE_Int
hypre_MPI_Finalize( )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Finalize();
}

HYPRE_Int
hypre_MPI_Abort( hypre_MPI_Comm comm,
                 HYPRE_Int      errorcode )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Abort(comm, (hypre_int)errorcode);
}

HYPRE_Real
hypre_MPI_Wtime( )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return MPI_Wtime();
}

HYPRE_Real
hypre_MPI_Wtick( )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return MPI_Wtick();
}

HYPRE_Int
hypre_MPI_Barrier( hypre_MPI_Comm comm )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Barrier(comm);
}

HYPRE_Int
hypre_MPI_Comm_create( hypre_MPI_Comm   comm,
                       hypre_MPI_Group  group,
                       hypre_MPI_Comm  *newcomm )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Comm_create(comm, group, newcomm);
}

HYPRE_Int
hypre_MPI_Comm_dup( hypre_MPI_Comm  comm,
                    hypre_MPI_Comm *newcomm )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Comm_dup(comm, newcomm);
}

HYPRE_Int
hypre_MPI_Comm_size( hypre_MPI_Comm  comm,
                     HYPRE_Int      *size )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int mpi_size;
   HYPRE_Int ierr;
   ierr = (HYPRE_Int) MPI_Comm_size(comm, &mpi_size);
#ifdef TREAT_THREAD_AS_RANK
   *size = (HYPRE_Int) (mpi_size * g_num_of_threads);
#else
   *size = (HYPRE_Int) mpi_size;
#endif
   return ierr;
}

HYPRE_Int
hypre_MPI_Comm_rank( hypre_MPI_Comm  comm,
                     HYPRE_Int      *rank )
{ 
#ifdef TREAT_THREAD_AS_RANK
	HYPRE_Int ierr=MPI_SUCCESS;
   *rank = (HYPRE_Int) (g_rank);
#else
   hypre_int mpi_rank;
   HYPRE_Int ierr;
   ierr = (HYPRE_Int) MPI_Comm_rank(comm, &mpi_rank);
   *rank = (HYPRE_Int) mpi_rank;
#endif

   return ierr;
}

HYPRE_Int
hypre_MPI_Comm_free( hypre_MPI_Comm *comm )
{
#ifdef print_mpi_calls
	printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Comm_free(comm);
}

HYPRE_Int
hypre_MPI_Comm_group( hypre_MPI_Comm   comm,
                      hypre_MPI_Group *group )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Comm_group(comm, group);
}

HYPRE_Int
hypre_MPI_Comm_split( hypre_MPI_Comm  comm,
                      HYPRE_Int       n,
                      HYPRE_Int       m,
                      hypre_MPI_Comm *comms )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Comm_split(comm, (hypre_int)n, (hypre_int)m, comms);
}

HYPRE_Int
hypre_MPI_Group_incl( hypre_MPI_Group  group,
                      HYPRE_Int        n,
                      HYPRE_Int       *ranks,
                      hypre_MPI_Group *newgroup )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int *mpi_ranks;
   HYPRE_Int  i;
   HYPRE_Int  ierr;

   mpi_ranks = hypre_TAlloc(hypre_int, n);
   for (i = 0; i < n; i++)
   {
      mpi_ranks[i] = (hypre_int) ranks[i];
   }
   ierr = (HYPRE_Int) MPI_Group_incl(group, (hypre_int)n, mpi_ranks, newgroup);
   hypre_TFree(mpi_ranks);

   return ierr;
}

HYPRE_Int
hypre_MPI_Group_free( hypre_MPI_Group *group )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Group_free(group);
}

HYPRE_Int
hypre_MPI_Address( void           *location,
                   hypre_MPI_Aint *address )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

#if MPI_VERSION > 1
   return (HYPRE_Int) MPI_Get_address(location, address);
#else
   return (HYPRE_Int) MPI_Address(location, address);
#endif
}

HYPRE_Int
hypre_MPI_Get_count( hypre_MPI_Status   *status,
                     hypre_MPI_Datatype  datatype,
                     HYPRE_Int          *count )
{
#ifdef print_mpi_calls
	printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int mpi_count;
   HYPRE_Int ierr;

#ifdef TREAT_THREAD_AS_RANK
   //damodar
   int temp_tag = status->MPI_TAG;
   int temp_src = status->MPI_SOURCE;
   //status->MPI_TAG = temp_tag == MPI_ANY_TAG ? MPI_ANY_TAG : (int)0x0000ffff * temp_src + temp_tag % (int)0x0000ffff;
   status->MPI_TAG = temp_tag == MPI_ANY_TAG ? MPI_ANY_TAG : (temp_src * src_multiplier) + (g_rank * dest_multiplier) + temp_tag % dest_multiplier;
   status->MPI_SOURCE = temp_src /g_num_of_threads;
   ierr = (HYPRE_Int) MPI_Get_count(status, datatype, &mpi_count);
   *count = (HYPRE_Int) mpi_count;
   status->MPI_TAG = temp_tag;
   status->MPI_SOURCE = temp_src;
   return ierr;

#else
   ierr = (HYPRE_Int) MPI_Get_count(status, datatype, &mpi_count);
   *count = (HYPRE_Int) mpi_count;
   return ierr;
#endif
}

HYPRE_Int
hypre_MPI_Alltoall( void               *sendbuf,
                    HYPRE_Int           sendcount,
                    hypre_MPI_Datatype  sendtype,
                    void               *recvbuf,
                    HYPRE_Int           recvcount,
                    hypre_MPI_Datatype  recvtype,
                    hypre_MPI_Comm      comm )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Alltoall(sendbuf, (hypre_int)sendcount, sendtype,
                                   recvbuf, (hypre_int)recvcount, recvtype, comm);
}

HYPRE_Int
hypre_MPI_Allgather( void               *sendbuf,
                     HYPRE_Int           sendcount,
                     hypre_MPI_Datatype  sendtype,
                     void               *recvbuf,
                     HYPRE_Int           recvcount,
                     hypre_MPI_Datatype  recvtype,
                     hypre_MPI_Comm      comm ) 
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Allgather(sendbuf, (hypre_int)sendcount, sendtype,
                                    recvbuf, (hypre_int)recvcount, recvtype, comm);
}

HYPRE_Int
hypre_MPI_Allgatherv( void               *sendbuf,
                      HYPRE_Int           sendcount,
                      hypre_MPI_Datatype  sendtype,
                      void               *recvbuf,
                      HYPRE_Int          *recvcounts,
                      HYPRE_Int          *displs, 
                      hypre_MPI_Datatype  recvtype,
                      hypre_MPI_Comm      comm ) 
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int *mpi_recvcounts, *mpi_displs, csize;
   HYPRE_Int  i;
   HYPRE_Int  ierr;

   MPI_Comm_size(comm, &csize);
   mpi_recvcounts = hypre_TAlloc(hypre_int, csize);
   mpi_displs = hypre_TAlloc(hypre_int, csize);
   for (i = 0; i < csize; i++)
   {
      mpi_recvcounts[i] = (hypre_int) recvcounts[i];
      mpi_displs[i] = (hypre_int) displs[i];
   }
   ierr = (HYPRE_Int) MPI_Allgatherv(sendbuf, (hypre_int)sendcount, sendtype,
                                     recvbuf, mpi_recvcounts, mpi_displs, 
                                     recvtype, comm);
   hypre_TFree(mpi_recvcounts);
   hypre_TFree(mpi_displs);

   return ierr;
}

HYPRE_Int
hypre_MPI_Gather( void               *sendbuf,
                  HYPRE_Int           sendcount,
                  hypre_MPI_Datatype  sendtype,
                  void               *recvbuf,
                  HYPRE_Int           recvcount,
                  hypre_MPI_Datatype  recvtype,
                  HYPRE_Int           root,
                  hypre_MPI_Comm      comm )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Gather(sendbuf, (hypre_int) sendcount, sendtype,
                                 recvbuf, (hypre_int) recvcount, recvtype,
                                 (hypre_int)root, comm);
}

HYPRE_Int
hypre_MPI_Gatherv(void               *sendbuf,
                  HYPRE_Int           sendcount,
                  hypre_MPI_Datatype  sendtype,
                  void               *recvbuf,
                  HYPRE_Int          *recvcounts,
                  HYPRE_Int          *displs,
                  hypre_MPI_Datatype  recvtype,
                  HYPRE_Int           root,
                  hypre_MPI_Comm      comm )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int *mpi_recvcounts = NULL;
   hypre_int *mpi_displs = NULL;
   hypre_int csize, croot;
   HYPRE_Int  i;
   HYPRE_Int  ierr;

   MPI_Comm_size(comm, &csize);
   MPI_Comm_rank(comm, &croot);
   if (croot == (hypre_int) root)
   {
      mpi_recvcounts = hypre_TAlloc(hypre_int, csize);
      mpi_displs = hypre_TAlloc(hypre_int, csize);
      for (i = 0; i < csize; i++)
      {
         mpi_recvcounts[i] = (hypre_int) recvcounts[i];
         mpi_displs[i] = (hypre_int) displs[i];
      }
   }
   ierr = (HYPRE_Int) MPI_Gatherv(sendbuf, (hypre_int)sendcount, sendtype,
                                     recvbuf, mpi_recvcounts, mpi_displs, 
                                     recvtype, (hypre_int) root, comm);
   hypre_TFree(mpi_recvcounts);
   hypre_TFree(mpi_displs);

   return ierr;
}

HYPRE_Int
hypre_MPI_Scatter( void               *sendbuf,
                   HYPRE_Int           sendcount,
                   hypre_MPI_Datatype  sendtype,
                   void               *recvbuf,
                   HYPRE_Int           recvcount,
                   hypre_MPI_Datatype  recvtype,
                   HYPRE_Int           root,
                   hypre_MPI_Comm      comm )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Scatter(sendbuf, (hypre_int)sendcount, sendtype,
                                  recvbuf, (hypre_int)recvcount, recvtype,
                                  (hypre_int)root, comm);
}

HYPRE_Int
hypre_MPI_Scatterv(void               *sendbuf,
                   HYPRE_Int          *sendcounts,
                   HYPRE_Int          *displs,
                   hypre_MPI_Datatype  sendtype,
                   void               *recvbuf,
                   HYPRE_Int           recvcount,
                   hypre_MPI_Datatype  recvtype,
                   HYPRE_Int           root,
                   hypre_MPI_Comm      comm )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int *mpi_sendcounts = NULL;
   hypre_int *mpi_displs = NULL;
   hypre_int csize, croot;
   HYPRE_Int  i;
   HYPRE_Int  ierr;

   MPI_Comm_size(comm, &csize);
   MPI_Comm_rank(comm, &croot);
   if (croot == (hypre_int) root)
   {
      mpi_sendcounts = hypre_TAlloc(hypre_int, csize);
      mpi_displs = hypre_TAlloc(hypre_int, csize);
      for (i = 0; i < csize; i++)
      {
         mpi_sendcounts[i] = (hypre_int) sendcounts[i];
         mpi_displs[i] = (hypre_int) displs[i];
      }
   }
   ierr = (HYPRE_Int) MPI_Scatterv(sendbuf, mpi_sendcounts, mpi_displs, sendtype,
                                     recvbuf, (hypre_int) recvcount, 
                                     recvtype, (hypre_int) root, comm);
   hypre_TFree(mpi_sendcounts);
   hypre_TFree(mpi_displs);

   return ierr;
}

HYPRE_Int
hypre_MPI_Bcast( void               *buffer,
                 HYPRE_Int           count,
                 hypre_MPI_Datatype  datatype,
                 HYPRE_Int           root,
                 hypre_MPI_Comm      comm ) 
{ 
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Bcast(buffer, (hypre_int)count, datatype,
                                (hypre_int)root, comm);
}

HYPRE_Int
hypre_MPI_Send( void               *buf,
                HYPRE_Int           count,
                hypre_MPI_Datatype  datatype,
                HYPRE_Int           dest,
                HYPRE_Int           tag,
                hypre_MPI_Comm      comm ) 
{ 
#ifdef print_mpi_calls
	printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

#ifdef TREAT_THREAD_AS_RANK
	int new_tag, real_dest = dest / g_num_of_threads;
	int src_thread = g_thread_id, dest_thread = dest % g_num_of_threads;
	new_tag = (src_thread * src_multiplier) + (dest_thread * dest_multiplier) + tag % dest_multiplier;

	if(tag > dest_multiplier)
		printf("###### increase bits for tag by environment variable HYPRE_TAG. %d send: dest %d, real dest %d, tag %d, new_tag %d ########\n", g_rank, dest, real_dest, tag, new_tag);


	return (HYPRE_Int) MPI_Send(buf, (hypre_int)count, datatype, (hypre_int)real_dest, (hypre_int)new_tag, comm);

#else
	int new_tag=tag, rank=g_rank, real_dest = dest;
	printf("%d send : dest %d, real dest %d, tag %d, new_tag %d\n", rank ,dest, real_dest, tag, new_tag);
   return (HYPRE_Int) MPI_Send(buf, (hypre_int)count, datatype,
                               (hypre_int)dest, (hypre_int)tag, comm);
#endif
}

HYPRE_Int
hypre_MPI_Recv( void               *buf,
                HYPRE_Int           count,
                hypre_MPI_Datatype  datatype,
                HYPRE_Int           source,
                HYPRE_Int           tag,
                hypre_MPI_Comm      comm,
                hypre_MPI_Status   *status )
{ 
#ifdef print_mpi_calls
	printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

#ifdef TREAT_THREAD_AS_RANK
	int real_source = source == MPI_ANY_SOURCE ? MPI_ANY_SOURCE : source / g_num_of_threads;
	int dest_thread = g_thread_id, src_thread = source % g_num_of_threads;
	int new_tag = tag == MPI_ANY_TAG ? MPI_ANY_TAG : (src_thread * src_multiplier) + (dest_thread * dest_multiplier) + tag % dest_multiplier;

	if(source == MPI_ANY_SOURCE && tag != MPI_ANY_TAG)	//not handled cause we need to know src_thread to calculate new_tag
		printf("condition of source == MPI_ANY_SOURCE && tag != MPI_ANY_TAG is NOT handled in hypre_MPI_Recv\n");

#ifdef print_mpi_calls
	printf("%d recv: source %d, real source %d, tag %d, new_tag %d\n", g_rank ,source, real_source, tag, new_tag);
#endif

	int flag = MPI_Recv(buf, (hypre_int)count, datatype, (hypre_int)real_source, (hypre_int)new_tag, comm, status);

	if(status != MPI_STATUS_IGNORE)
	{
		   int incoming_tag = status->MPI_TAG;
		   int src_thread =  incoming_tag / src_multiplier;
		   incoming_tag = incoming_tag & src_eliminate_and;
		   int dest_thread = incoming_tag / dest_multiplier;
		   //incoming_tag = incoming_tag - src_thread * (int)dest_multiplier;
		   incoming_tag = incoming_tag - dest_thread * (int)dest_multiplier;
		   status->MPI_SOURCE = status->MPI_SOURCE * g_num_of_threads + src_thread;
		   status->MPI_TAG = incoming_tag;
	}

#else
	int new_tag=tag, rank=g_rank, real_source = source;
	printf("%d recv : source %d, real source %d, tag %d, new_tag %d\n", rank ,source, real_source, tag, new_tag);
   return (HYPRE_Int) MPI_Recv(buf, (hypre_int)count, datatype,
                               (hypre_int)source, (hypre_int)tag, comm, status);
#endif
}

HYPRE_Int
hypre_MPI_Isend( void               *buf,
                 HYPRE_Int           count,
                 hypre_MPI_Datatype  datatype,
                 HYPRE_Int           dest,
                 HYPRE_Int           tag,
                 hypre_MPI_Comm      comm,
                 hypre_MPI_Request  *request )
{ 
#ifdef print_mpi_calls
	printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

#ifdef TREAT_THREAD_AS_RANK


	int new_tag, real_dest = dest / g_num_of_threads;
	int src_thread = g_thread_id , dest_thread = dest % g_num_of_threads;
	new_tag = (src_thread * src_multiplier) + (dest_thread * dest_multiplier) + tag % dest_multiplier;

	if(tag > dest_multiplier)
		printf("###### increase bits for tag by environment variable HYPRE_TAG. %d send: dest %d, real dest %d, tag %d, new_tag %d ########\n", g_rank, dest, real_dest, tag, new_tag);


#ifdef print_mpi_calls
	printf("%d send i: dest %d, real dest %d, tag %d, new_tag %d\n", g_rank, dest, real_dest, tag, new_tag);
#endif
	return (HYPRE_Int) MPI_Isend(buf, (hypre_int)count, datatype, (hypre_int)real_dest, (hypre_int)new_tag, comm, request);

#else
	int new_tag=tag, rank=g_rank, real_dest = dest;
	printf("%d send i: dest %d, real dest %d, tag %d, new_tag %d\n", rank ,dest, real_dest, tag, new_tag);
   return (HYPRE_Int) MPI_Isend(buf, (hypre_int)count, datatype,
                                (hypre_int)dest, (hypre_int)tag, comm, request);
#endif
}

HYPRE_Int
hypre_MPI_Irecv( void               *buf,
                 HYPRE_Int           count,
                 hypre_MPI_Datatype  datatype,
                 HYPRE_Int           source,
                 HYPRE_Int           tag,
                 hypre_MPI_Comm      comm,
                 hypre_MPI_Request  *request )
{ 
#ifdef print_mpi_calls
	printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

#ifdef TREAT_THREAD_AS_RANK
	int real_source = source == MPI_ANY_SOURCE ? MPI_ANY_SOURCE : source / g_num_of_threads;
	int dest_thread = g_thread_id, src_thread = source % g_num_of_threads;
	int new_tag = tag == MPI_ANY_TAG ? MPI_ANY_TAG : (src_thread * src_multiplier) + (dest_thread * dest_multiplier) + tag % dest_multiplier;

	if(source == MPI_ANY_SOURCE && tag != MPI_ANY_TAG)	//not handled cause we need to know src_thread to calculate new_tag
			printf("condition of source == MPI_ANY_SOURCE && tag != MPI_ANY_TAG is NOT handled in hypre_MPI_Irecv\n");
#ifdef print_mpi_calls
	printf("%d recv i: source %d, real source %d, tag %d, new_tag %d\n", g_rank ,source, real_source, tag, new_tag);
#endif
	return (HYPRE_Int) MPI_Irecv(buf, (hypre_int)count, datatype, (hypre_int)real_source, (hypre_int)new_tag, comm, request);

#else
	int new_tag=tag, rank=g_rank, real_source = source;
	printf("%d recv i: source %d, real source %d, tag %d, new_tag %d\n", rank ,source, real_source, tag, new_tag);
	return (HYPRE_Int) MPI_Irecv(buf, (hypre_int)count, datatype,
                                (hypre_int)source, (hypre_int)tag, comm, request);
#endif
}

HYPRE_Int
hypre_MPI_Send_init( void               *buf,
                     HYPRE_Int           count,
                     hypre_MPI_Datatype  datatype,
                     HYPRE_Int           dest,
                     HYPRE_Int           tag, 
                     hypre_MPI_Comm      comm,
                     hypre_MPI_Request  *request )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Send_init(buf, (hypre_int)count, datatype,
                                    (hypre_int)dest, (hypre_int)tag,
                                    comm, request);
}

HYPRE_Int
hypre_MPI_Recv_init( void               *buf,
                     HYPRE_Int           count,
                     hypre_MPI_Datatype  datatype,
                     HYPRE_Int           dest,
                     HYPRE_Int           tag, 
                     hypre_MPI_Comm      comm,
                     hypre_MPI_Request  *request )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Recv_init(buf, (hypre_int)count, datatype,
                                    (hypre_int)dest, (hypre_int)tag,
                                    comm, request);
}

HYPRE_Int
hypre_MPI_Irsend( void               *buf,
                  HYPRE_Int           count,
                  hypre_MPI_Datatype  datatype,
                  HYPRE_Int           dest,
                  HYPRE_Int           tag, 
                  hypre_MPI_Comm      comm,
                  hypre_MPI_Request  *request )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Irsend(buf, (hypre_int)count, datatype,
                                 (hypre_int)dest, (hypre_int)tag, comm, request);
}

HYPRE_Int
hypre_MPI_Startall( HYPRE_Int          count,
                    hypre_MPI_Request *array_of_requests )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Startall((hypre_int)count, array_of_requests);
}

HYPRE_Int
hypre_MPI_Probe( HYPRE_Int         source,
                 HYPRE_Int         tag,
                 hypre_MPI_Comm    comm,
                 hypre_MPI_Status *status )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Probe((hypre_int)source, (hypre_int)tag, comm, status);
}

HYPRE_Int
hypre_MPI_Iprobe( HYPRE_Int         source,
                  HYPRE_Int         tag,
                  hypre_MPI_Comm    comm,
                  HYPRE_Int        *flag,
                  hypre_MPI_Status *status )
{
#ifdef print_mpi_calls
	printf("%d hypre_MPI_Iprobe %d, %d\n",g_rank, source, tag);
#endif

   hypre_int mpi_flag;
   HYPRE_Int ierr;

   //new_tag = (source * src_multiplier) + (rank * dest_multiplier) + tag % dest_multiplier;

#ifdef TREAT_THREAD_AS_RANK

   int thread_id = g_thread_id;
   if(source == hypre_MPI_ANY_SOURCE && tag==MPI_ANY_TAG)
   {
	   ierr = (HYPRE_Int) MPI_Iprobe((hypre_int)source, (hypre_int)tag, comm, &mpi_flag, status);
	   //compare tag value with received tag and return accordingly
	   *flag = (HYPRE_Int) mpi_flag;
	   if(mpi_flag)
	   {
		   int incoming_tag = status->MPI_TAG;
		   int src =  incoming_tag / src_multiplier;
		   incoming_tag = incoming_tag & src_eliminate_and;
		   int dest = incoming_tag / dest_multiplier;
		   incoming_tag = incoming_tag - dest * (int)dest_multiplier;
		   if(dest == thread_id)
		   {
			   status->MPI_SOURCE = status->MPI_SOURCE * g_num_of_threads + src;
			   status->MPI_TAG = incoming_tag;	//big assumption: Original tag generated are ALWAYs < 0x0000ffff, else this will fail
		   }

	   }
	   return ierr;
   }
   else if(source == hypre_MPI_ANY_SOURCE && tag!=MPI_ANY_TAG)	// can lead to deadlock. e.g. 0 sends 2 msgs with tag 100 and 200. At 1 200 arrives 1st and 1 probes for msg tag 100, MPI_IProbe will always return 200 and we never reach 100 for which 1 is probing
   {
	   //using MPI_ANY_TAG is faster than generating tag for all sources. Use this if supported by MPI
	   // have to probe with MPI_ANY_TAG, as without know source, tag can not be converted. This is bad. will lead to serialized probe and receive.
	   *flag = 0;
	   ierr = (HYPRE_Int) MPI_Iprobe((hypre_int)source, MPI_ANY_TAG, comm, &mpi_flag, status);
	   if(mpi_flag)
	   {
		   int incoming_tag = status->MPI_TAG;
		   int src =  incoming_tag / src_multiplier;
		   incoming_tag = incoming_tag & src_eliminate_and;
		   int dest = incoming_tag / dest_multiplier;
		   incoming_tag = incoming_tag - dest * (int)dest_multiplier;

		   if(dest == thread_id && tag == incoming_tag)
		   {
			   status->MPI_SOURCE = status->MPI_SOURCE * g_num_of_threads + src;
			   status->MPI_TAG = incoming_tag;
			   *flag = 1;
		   }
	   }

/*
	   int i, dest_thread = g_thread_id, j;
	   for(i=0; i<g_num_of_threads; i++)
	   //for(i=dest_thread, j=0; j < g_num_of_threads; i=(i+1)%g_num_of_threads, j++)
	   {
			int  src_thread = i;
			int new_tag =  (src_thread * src_multiplier) + (dest_thread * dest_multiplier) + tag % dest_multiplier;
			*flag = 0;
			ierr = (HYPRE_Int) MPI_Iprobe((hypre_int)source, new_tag, comm, &mpi_flag, status);
			if(mpi_flag)
			{
			   int incoming_tag = status->MPI_TAG;
			   int src =  incoming_tag / src_multiplier;
			   incoming_tag = incoming_tag & src_eliminate_and;
			   int dest = incoming_tag / dest_multiplier;
			   incoming_tag = incoming_tag - dest * (int)dest_multiplier;

			   if(dest == thread_id && tag == incoming_tag)
			   {
				   status->MPI_SOURCE = status->MPI_SOURCE * g_num_of_threads + src;
				   status->MPI_TAG = incoming_tag;
				   *flag = 1;
				   break;
			   }
			}
	   }
*/

   }
   else if(source != hypre_MPI_ANY_SOURCE && tag==MPI_ANY_TAG)
   {
		*flag = 0;
		int real_src = source / g_num_of_threads;
		ierr = (HYPRE_Int) MPI_Iprobe((hypre_int)real_src, tag, comm, &mpi_flag, status);
		if(mpi_flag)
		{
		   int incoming_tag = status->MPI_TAG;
		   int src =  incoming_tag / src_multiplier;
		   incoming_tag = incoming_tag & src_eliminate_and;
		   int dest = incoming_tag / dest_multiplier;
		   incoming_tag = incoming_tag - dest * (int)dest_multiplier;
		   int fake_src = status->MPI_SOURCE * g_num_of_threads + src;
			if(dest == thread_id && source == fake_src)
			{
				status->MPI_SOURCE = fake_src;
				status->MPI_TAG = incoming_tag;
				*flag = 1;
			}
		}
   }
   else if(source != hypre_MPI_ANY_SOURCE && tag!=MPI_ANY_TAG)
   {
		*flag = 0;
		int real_src = source / g_num_of_threads;
	   	int dest_thread = g_thread_id , src_thread = source % g_num_of_threads;
		int new_tag = (src_thread * src_multiplier) + (dest_thread * dest_multiplier) + tag % dest_multiplier;
		ierr = (HYPRE_Int) MPI_Iprobe((hypre_int)real_src, new_tag, comm, &mpi_flag, status);
		if(mpi_flag)
		{
		   int incoming_tag = status->MPI_TAG;
		   int src =  incoming_tag / src_multiplier;
		   incoming_tag = incoming_tag & src_eliminate_and;
		   int dest = incoming_tag / dest_multiplier;
		   incoming_tag = incoming_tag - dest * (int)dest_multiplier;
		   int fake_src = status->MPI_SOURCE * g_num_of_threads + src;
			if(dest == thread_id && source == fake_src && tag == incoming_tag)
			{
				status->MPI_SOURCE = fake_src;
				status->MPI_TAG = incoming_tag;
				*flag = 1;
			}
		}
   }

#else
   ierr = (HYPRE_Int) MPI_Iprobe((hypre_int)source, (hypre_int)tag, comm, &mpi_flag, status);
   *flag = (HYPRE_Int) mpi_flag;
   return ierr;
#endif

}

HYPRE_Int
hypre_MPI_Test( hypre_MPI_Request *request,
                HYPRE_Int         *flag,
                hypre_MPI_Status  *status )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int mpi_flag;
   HYPRE_Int ierr;
   ierr = (HYPRE_Int) MPI_Test(request, &mpi_flag, status);
   *flag = (HYPRE_Int) mpi_flag;
   return ierr;
}

HYPRE_Int
hypre_MPI_Testall( HYPRE_Int          count,
                   hypre_MPI_Request *array_of_requests,
                   HYPRE_Int         *flag,
                   hypre_MPI_Status  *array_of_statuses )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int mpi_flag;
   HYPRE_Int ierr;
   ierr = (HYPRE_Int) MPI_Testall((hypre_int)count, array_of_requests,
                                  &mpi_flag, array_of_statuses);
   *flag = (HYPRE_Int) mpi_flag;
   return ierr;
}

HYPRE_Int
hypre_MPI_Wait( hypre_MPI_Request *request,
                hypre_MPI_Status  *status )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Wait(request, status);
}

HYPRE_Int
hypre_MPI_Waitall( HYPRE_Int          count,
                   hypre_MPI_Request *array_of_requests,
                   hypre_MPI_Status  *array_of_statuses )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Waitall((hypre_int)count,
                                  array_of_requests, array_of_statuses);
}

HYPRE_Int
hypre_MPI_Waitany( HYPRE_Int          count,
                   hypre_MPI_Request *array_of_requests,
                   HYPRE_Int         *index,
                   hypre_MPI_Status  *status )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int mpi_index;
   HYPRE_Int ierr;
   ierr = (HYPRE_Int) MPI_Waitany((hypre_int)count, array_of_requests,
                                  &mpi_index, status);
   *index = (HYPRE_Int) mpi_index;
   return ierr;
}

HYPRE_Int
hypre_MPI_Allreduce( void              *sendbuf,
                     void              *recvbuf,
                     HYPRE_Int          count,
                     hypre_MPI_Datatype datatype,
                     hypre_MPI_Op       op,
                     hypre_MPI_Comm     comm )
{
#ifdef print_mpi_calls
	printf("%d %s, %s, %d, count : %d, datatype: %s, op: %s \n",g_rank, __FUNCTION__, __FILE__, __LINE__, count , getOpName(datatype), getOpName(op));
#endif

#ifdef TREAT_THREAD_AS_RANK
	int i, j;
	int mpi_datatype_size;
	MPI_Type_size(datatype, &mpi_datatype_size);

	hypre_copy_data_for_sync_collectives(sendbuf, recvbuf, count, datatype);

	int thread_id = g_thread_id;

	if(thread_id==0)	//0 th thread reduces first across threads and then across ranks
	{
		atomic_store_explicit(&g_barrier, g_num_of_threads, memory_order_seq_cst);

		//try macro somehow for operations and may be datatype as well???
		int result;
		//print OPs. ints have some extra ops. that why failing????
		if(datatype==MPI_DOUBLE)
		{
			double * collective_sync_buff = (double *) g_collective_sync_buff;
			double * local_reduction = (double*) malloc(sizeof(double)*count);
			local_threaded_reduce(collective_sync_buff,local_reduction, count, op, result);
			MPI_Allreduce(local_reduction, recvbuf, (hypre_int)count, datatype, op, comm);
			free(local_reduction);
			collective_sync_buff = NULL;
		}
		else if(datatype==MPI_INT)
		{
			int * collective_sync_buff = (int *) g_collective_sync_buff;
			int * local_reduction = (int*) malloc(sizeof(int)*count);
			int k=0;
			//for(k=0;k<count*g_num_of_threads; k++)
			//	printf("%d ",collective_sync_buff[k]);

			local_threaded_reduce_for_INT(collective_sync_buff,local_reduction, count, op, result);
			MPI_Allreduce(local_reduction, recvbuf, (hypre_int)count, datatype, op, comm);
			free(local_reduction);
			collective_sync_buff = NULL;
		}
		else if(datatype==MPI_FLOAT)
		{
			float * collective_sync_buff = (float *) g_collective_sync_buff;
			float * local_reduction = (float*) malloc(sizeof(float)*count);
			local_threaded_reduce(collective_sync_buff,local_reduction, count, op, result);
			MPI_Allreduce(local_reduction, recvbuf, (hypre_int)count, datatype, op, comm);
			free(local_reduction);
			collective_sync_buff = NULL;
		}
		else	printf("reduction for other datatypes not yet implemented in hypre mpistubs.c\n");

		for(i=0; i<count*mpi_datatype_size ; i++)
			((unsigned char *)g_collective_sync_buff)[i] = ((unsigned char *)recvbuf)[i];	//copy data

		//printf("%d reduced copying complete by thread 0\n", me);
		atomic_fetch_add_explicit(&g_collective_sync_copy_count, 1, memory_order_seq_cst);	//copying of data over
		//printf("%d - %d waiting for child threads to finish\n", g_rank, thread_id);
		while(atomic_load_explicit(&g_collective_sync_copy_count, memory_order_seq_cst) <  g_num_of_threads );//{printf("%d wait %s %d\n",thread_id, __FILE__, __LINE__);}	//thread 0 waits before freeing memory, till all other threads copying data

		free(g_collective_sync_buff);
		g_collective_sync_buff = NULL;
		atomic_store_explicit(&g_collective_sync_copy_count, 0, memory_order_seq_cst);	//reset g_collective_sync_copy_count from prev reduce
		atomic_store_explicit(&g_collective_sync_count, 0, memory_order_seq_cst);	//signal other threads

		while(atomic_load_explicit(&g_barrier, memory_order_seq_cst) > 1 );	//wait till all child threads exit.
	}
	else
	{
		while(atomic_load_explicit(&g_collective_sync_copy_count, memory_order_seq_cst) ==  0 );//{printf("%d wait %s %d\n",thread_id, __FILE__, __LINE__);}	//all other threads wait.
		//read values from global buffer
		for(i=0; i<count*mpi_datatype_size ; i++)
			((unsigned char *)recvbuf)[i] = ((unsigned char *)g_collective_sync_buff)[i];	//copy data

		atomic_fetch_add_explicit(&g_collective_sync_copy_count, 1, memory_order_seq_cst);	//copying of data over

		while(atomic_load_explicit(&g_collective_sync_count, memory_order_seq_cst) > 0 );	//wait till variables are reset or it conflicts with next reduce

		atomic_fetch_add_explicit(&g_barrier, -1, memory_order_seq_cst);

	}

#else
   return (HYPRE_Int) MPI_Allreduce(sendbuf, recvbuf, (hypre_int)count,
                                    datatype, op, comm);
#endif
}

/*


HYPRE_Int
hypre_MPI_Allreduce( void              *sendbuf,
                     void              *recvbuf,
                     HYPRE_Int          count,
                     hypre_MPI_Datatype datatype,
                     hypre_MPI_Op       op,
                     hypre_MPI_Comm     comm )
{
#ifdef print_mpi_calls
	printf("%d %s, %s, %d, count : %d, datatype: %s, op: %s \n",g_rank, __FUNCTION__, __FILE__, __LINE__, count , getOpName(datatype), getOpName(op));
#endif

#ifdef TREAT_THREAD_AS_RANK
	int i, j;
	int mpi_datatype_size;
	MPI_Type_size(datatype, &mpi_datatype_size);

	hypre_copy_data_for_sync_collectives(sendbuf, recvbuf, count, datatype);

	int thread_id = g_thread_id;

	if(thread_id==0)	//0 th thread reduces first across threads and then across ranks
	{
		//try macro somehow for operations and may be datatype as well???
		int result;
		//print OPs. ints have some extra ops. that why failing????
		if(datatype==MPI_DOUBLE)
		{
			double * collective_sync_buff = (double *) g_collective_sync_buff;
			double * local_reduction = (double*) malloc(sizeof(double)*count);
			local_threaded_reduce(collective_sync_buff,local_reduction, count, op, result);
			MPI_Allreduce(local_reduction, g_collective_sync_buff, (hypre_int)count, datatype, op, comm);
			free(local_reduction);
			collective_sync_buff = NULL;
		}
		else if(datatype==MPI_INT)
		{
			int * collective_sync_buff = (int *) g_collective_sync_buff;
			int * local_reduction = (int*) malloc(sizeof(int)*count);
			int k=0;
			//for(k=0;k<count*g_num_of_threads; k++)
			//	printf("%d ",collective_sync_buff[k]);

			local_threaded_reduce_for_INT(collective_sync_buff,local_reduction, count, op, result);
			MPI_Allreduce(local_reduction, g_collective_sync_buff, (hypre_int)count, datatype, op, comm);
			free(local_reduction);
			collective_sync_buff = NULL;
		}
		else if(datatype==MPI_FLOAT)
		{
			float * collective_sync_buff = (float *) g_collective_sync_buff;
			float * local_reduction = (float*) malloc(sizeof(float)*count);
			local_threaded_reduce(collective_sync_buff,local_reduction, count, op, result);
			MPI_Allreduce(local_reduction, g_collective_sync_buff, (hypre_int)count, datatype, op, comm);
			free(local_reduction);
			collective_sync_buff = NULL;
		}
		else	printf("reduction for other datatypes not yet implemented in hypre mpistubs.c\n");


		//printf("%d reduced copying complete by thread 0\n", me);
		atomic_fetch_add_explicit(&g_collective_sync_copy_count, 1, memory_order_seq_cst);	//copying of data over
		//printf("%d - %d waiting for child threads to finish\n", g_rank, thread_id);

		for(i=0; i<count*mpi_datatype_size ; i++)
			((unsigned char *)recvbuf)[i] = ((unsigned char *)g_collective_sync_buff)[i];	//copy data



	}
	else
	{
		while(atomic_load_explicit(&g_collective_sync_copy_count, memory_order_seq_cst) ==  0 );//{printf("%d wait %s %d\n",thread_id, __FILE__, __LINE__);}	//all other threads wait.
		//read values from global buffer
		for(i=0; i<count*mpi_datatype_size ; i++)
			((unsigned char *)recvbuf)[i] = ((unsigned char *)g_collective_sync_buff)[i];	//copy data

	}



#else
   return (HYPRE_Int) MPI_Allreduce(sendbuf, recvbuf, (hypre_int)count,
                                    datatype, op, comm);
#endif
}
*/

HYPRE_Int
hypre_MPI_Reduce( void               *sendbuf,
                  void               *recvbuf,
                  HYPRE_Int           count,
                  hypre_MPI_Datatype  datatype,
                  hypre_MPI_Op        op,
                  HYPRE_Int           root,
                  hypre_MPI_Comm      comm )
{ 
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Reduce(sendbuf, recvbuf, (hypre_int)count,
                                 datatype, op, (hypre_int)root, comm);
}

HYPRE_Int
hypre_MPI_Scan( void               *sendbuf,
                void               *recvbuf,
                HYPRE_Int           count,
                hypre_MPI_Datatype  datatype,
                hypre_MPI_Op        op,
                hypre_MPI_Comm      comm )
{ 
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Scan(sendbuf, recvbuf, (hypre_int)count,
                               datatype, op, comm);
}

HYPRE_Int
hypre_MPI_Request_free( hypre_MPI_Request *request )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Request_free(request);
}

HYPRE_Int
hypre_MPI_Type_contiguous( HYPRE_Int           count,
                           hypre_MPI_Datatype  oldtype,
                           hypre_MPI_Datatype *newtype )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Type_contiguous((hypre_int)count, oldtype, newtype);
}

HYPRE_Int
hypre_MPI_Type_vector( HYPRE_Int           count,
                       HYPRE_Int           blocklength,
                       HYPRE_Int           stride,
                       hypre_MPI_Datatype  oldtype,
                       hypre_MPI_Datatype *newtype )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Type_vector((hypre_int)count, (hypre_int)blocklength,
                                      (hypre_int)stride, oldtype, newtype);
}

HYPRE_Int
hypre_MPI_Type_hvector( HYPRE_Int           count,
                        HYPRE_Int           blocklength,
                        hypre_MPI_Aint      stride,
                        hypre_MPI_Datatype  oldtype,
                        hypre_MPI_Datatype *newtype )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

#if MPI_VERSION > 1
      return (HYPRE_Int) MPI_Type_create_hvector((hypre_int)count, (hypre_int)blocklength,
                                                 stride, oldtype, newtype);
#else
   return (HYPRE_Int) MPI_Type_hvector((hypre_int)count, (hypre_int)blocklength,
                                       stride, oldtype, newtype);
#endif
}

HYPRE_Int
hypre_MPI_Type_struct( HYPRE_Int           count,
                       HYPRE_Int          *array_of_blocklengths,
                       hypre_MPI_Aint     *array_of_displacements,
                       hypre_MPI_Datatype *array_of_types,
                       hypre_MPI_Datatype *newtype )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   hypre_int *mpi_array_of_blocklengths;
   HYPRE_Int  i;
   HYPRE_Int  ierr;

   mpi_array_of_blocklengths = hypre_TAlloc(hypre_int, count);
   for (i = 0; i < count; i++)
   {
      mpi_array_of_blocklengths[i] = (hypre_int) array_of_blocklengths[i];
   }

#if MPI_VERSION > 1
      ierr = (HYPRE_Int) MPI_Type_create_struct((hypre_int)count, mpi_array_of_blocklengths,
                                                array_of_displacements, array_of_types,
                                                newtype);
#else
      ierr = (HYPRE_Int) MPI_Type_struct((hypre_int)count, mpi_array_of_blocklengths,
                                         array_of_displacements, array_of_types,
                                         newtype);
#endif

   hypre_TFree(mpi_array_of_blocklengths);

   return ierr;
}

HYPRE_Int
hypre_MPI_Type_commit( hypre_MPI_Datatype *datatype )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Type_commit(datatype);
}

HYPRE_Int
hypre_MPI_Type_free( hypre_MPI_Datatype *datatype )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Type_free(datatype);
}

HYPRE_Int
hypre_MPI_Op_free( hypre_MPI_Op *op )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Op_free(op);
}

HYPRE_Int
hypre_MPI_Op_create( hypre_MPI_User_function *function, hypre_int commute, hypre_MPI_Op *op )
{
#ifdef print_mpi_calls
printf("%d %s, %s, %d\n",g_rank, __FUNCTION__, __FILE__, __LINE__);
#endif

   return (HYPRE_Int) MPI_Op_create(function, commute, op);
}

#endif

