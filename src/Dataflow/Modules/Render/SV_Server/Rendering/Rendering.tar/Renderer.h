/*
 *
 * Renderer: Superclass for renderers
 * $Id$
 *
 * Written by:
 *   Author: Eric Luke
 *   Department of Computer Science
 *   University of Utah
 *   Date: January 2001
 *
 */

#ifndef __Renderer_h_
#define __Renderer_h_

#include <stdio.h>
#include <list>

#include <Network/NetInterface.h>
#include <Message/ViewFrame.h>
#include <Thread/Runnable.h>
#include <Logging/Log.h>
#include <Compression/Compression.h>

namespace SemotusVisum {
namespace Rendering {

using namespace Message;
using namespace Network;
using namespace Logging;
using namespace Compression;

/**************************************
 
CLASS
   Renderer
   
KEYWORDS
   Rendering
   
DESCRIPTION

   The rendering superclass defines functions common to all viewing methods.
   This class holds a list of clients that are currently receiving
   rendering data from this renderer. 
   
****************************************/
class Renderer {
public:

  //////////
  // Constructor. Does not create an internal rendering thread.
  Renderer() : internalThread( NULL ), fullMessage( NULL ),
	       fullSize( 0 ), compress( NULL ), mGroup( NULL )  { }

  //////////
  // Constructor. Creates an internal rendering thread.
  Renderer( Runnable * runner, const char * name ) : fullMessage( NULL ),
						     fullSize( 0 ),
						     compress( NULL ),
						     mGroup( NULL ) {
    internalThread =
      new SemotusVisum::Thread::Thread( runner, name );
  }
  
  //////////
  // Destructor. Clears the list of clients, deletes internal thread.
  virtual ~Renderer() {
    
    /*if (internalThread) {
      internalThread->stop();
      delete internalThread;
      }*/
    
    //clients.clear();

    // Clean up our internal buffer.
    if ( fullMessage != NULL )
      delete fullMessage;
  }
  
  ////////
  // Adds callbacks to the network dispatch manager. Should be called
  // before the renderer is used.
  virtual void setCallbacks() = 0;
  
  //////////
  // Adds a client to the list of those receiving data from this
  // renderer.
  void addClient( const char * clientName );

  //////////
  // Deletes the given client from the list of those receiving data
  // from this renderer.
  void deleteClient( char * clientName );

  //////////
  // Returns true if this client is a client of the renderer.
  bool isClient( const char * clientName ) const;
  
  //////////
  // Transmits the given data to the clients. 
  virtual void sendRenderData( const char * data, int numBytes ) = 0;

  //////////
  // Name of this renderer.
  static const char * const name;// = "Renderer";

  //////////
  // Version of this renderer.
  static const char * const version;// = "0.0";
  
protected:
  
  // Wrapper to send a 'ViewFrame' message + data to the network.
  // If origSize is present, it is the uncompressed size of the data -
  // the parameter to put in the XML.
  void sendViewFrame( const int size, const char * data,
		      const int origSize=-1);

  // Wrapper that transmits data to the network.
  void transmitData( const char * data, const int numBytes );
  
  // Verifies that all clients are still connected. Updates the list
  // if clients are missing.
  void verifyClients();
  
  // List of clients subscribed to this renderer.
  list<char *>     clients;

  // Internal thread.
  SemotusVisum::Thread::Thread *internalThread;

  // Internal data buffer
  char * fullMessage;

  // Internal data buffer size
  int    fullSize;

  // Compression callback ID
  int compressionCallbackID;

  // Current compressor
  Compressor * compress;
  
  // Multicast group
  multicastGroup * mGroup;
};


}
}
#endif
//
// $Log$
// Revision 1.1  2003/06/18 22:23:36  simpson
// Adding CollabVis files/dirs
//
// Revision 1.8  2001/05/29 03:43:13  luke
// Merged in changed to allow code to compile/run on IRIX. Note that we have a problem with network byte order in the networking code....
//
// Revision 1.7  2001/05/24 23:03:26  luke
// First transmission successcd ..!
//
// Revision 1.6  2001/05/21 22:00:46  luke
// Got basic set viewing method to work. Problems still with reading 0 data from net and ignoring outbound messages
//
// Revision 1.5  2001/05/14 18:13:50  luke
// Finished documentation
//
// Revision 1.4  2001/05/14 17:55:36  luke
// New implementation of image renderer - uses a helper class for new thread
//
// Revision 1.3  2001/05/14 17:31:13  luke
// Moved driver to new spot.
//
// Revision 1.2  2001/04/05 21:15:21  luke
// Added header